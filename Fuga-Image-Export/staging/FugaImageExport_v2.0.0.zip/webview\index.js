/**
 * WebView entry point - handles message routing
 */

// Base64 helpers for the WebView side
function arrToB64(uint8) {
    let b64 = "";
    const chunk = 0x8000; // 32KB chunks are safe for the stack
    for (let i = 0; i < uint8.length; i += chunk) {
        b64 += String.fromCharCode.apply(null, uint8.subarray(i, i + chunk));
    }
    return btoa(b64);
}

function b64ToArr(str) {
    const bin = atob(str);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
        buf[i] = bin.charCodeAt(i);
    }
    return buf;
}

function postToHost(type, requestId, payload = {}) {
    if (window.uxpHost && typeof window.uxpHost.postMessage === "function") {
        window.uxpHost.postMessage({
            type,
            requestId,
            payload
        });
    }
}

/**
 * Performs high-quality downsampling using iterative step-down (Phase 6)
 */
function downsample(sourceCanvas, targetW, targetH) {
    let curW = sourceCanvas.width;
    let curH = sourceCanvas.height;
    let currentCanvas = sourceCanvas;

    // Step down by half until we are close to the target to maintain sharpness
    while (curW > targetW * 2) {
        const stepCanvas = document.createElement("canvas");
        curW = Math.floor(curW / 2);
        curH = Math.floor(curH / 2);
        stepCanvas.width = curW;
        stepCanvas.height = curH;
        const sctx = stepCanvas.getContext("2d");
        sctx.imageSmoothingEnabled = true;
        sctx.imageSmoothingQuality = 'high';
        sctx.drawImage(currentCanvas, 0, 0, curW, curH);
        currentCanvas = stepCanvas;
    }

    // Final resize to exact dimensions
    const finalCanvas = document.createElement("canvas");
    finalCanvas.width = targetW;
    finalCanvas.height = targetH;
    const fctx = finalCanvas.getContext("2d");
    fctx.imageSmoothingEnabled = true;
    fctx.imageSmoothingQuality = 'high';
    fctx.drawImage(currentCanvas, 0, 0, targetW, targetH);
    return finalCanvas;
}

function getByteSize(b64) {
    const padding = b64.endsWith("==") ? 2 : b64.endsWith("=") ? 1 : 0;
    return Math.floor((b64.length * 3) / 4) - padding;
}

let cancelSignal = false;

/**
 * Check if we should abort the current loop
 */
function checkCancel() {
    if (cancelSignal) throw new Error("Processing cancelled by user");
    return false;
}

/**
 * Sends a heartbeat to the host to prevent bridge timeouts
 */
function sendHeartbeat(requestId) {
    postToHost("heartbeat", requestId);
}

async function handleRequest(event) {
    const data = event && event.data ? event.data : event;
    if (!data || !data.type) return;

    const { type, requestId, payload } = data;

    try {
        const sourceFormat = payload && payload.sourceFormat ? payload.sourceFormat : payload && payload.format;

        // Ensure codecs are initialized if needed
        if (sourceFormat === 'jpg' || sourceFormat === 'jpeg') {
            await window.Codecs.initMozJpeg();
        } else if (sourceFormat === 'png') {
            await window.Codecs.initOxiPng();
        } else if (sourceFormat === 'webp') {
            await window.Codecs.initWebpDec();
        }
        if (payload && payload.format === 'webp') {
            await window.Codecs.initWebpEnc();
        }

        if (type === "cancel-request") {
            cancelSignal = true;
            return;
        }

        switch (type) {
            case "ping":
                postToHost("ping-result", requestId, { ok: true });
                break;

            case "process-image":
                cancelSignal = false; // Reset for new task
                if (!payload || !payload.inputBase64) {
                    throw new Error("Missing inputBase64 payload");
                }
                const inputArr = b64ToArr(payload.inputBase64);

                // 1. Decode Source (Byte-array for JPEG, Image object for PNG transparency)
                let canvas = document.getElementById("proc-canvas");
                let ctx = canvas.getContext("2d");
                let sourceWidth, sourceHeight;

                // 1a. WebP WASM Decoder Path
                if (sourceFormat === "webp" && window.Codecs.webpdec) {
                    try {
                        // Assumes squoosh webp_dec returns {width, height, data} or similar
                        const decoded = window.Codecs.webpdec.decode(inputArr);
                        canvas.width = decoded.width;
                        canvas.height = decoded.height;
                        ctx.putImageData(new ImageData(new Uint8ClampedArray(decoded.data), decoded.width, decoded.height), 0, 0);
                        sourceWidth = decoded.width;
                        sourceHeight = decoded.height;
                    } catch (e) {
                        throw new Error(`WebP WASM decode failed: ${e.message}`);
                    }
                }
                // 1b. Native image decoder path. Avoid jpeg-js memory caps for large JPEG sources.
                else if (sourceFormat === "png" || sourceFormat === "webp" || sourceFormat === "jpg" || sourceFormat === "jpeg") {
                    const img = new Image();
                    const imageMimeType = sourceFormat === "jpg" ? "image/jpeg" : `image/${sourceFormat}`;
                    const blob = new Blob([inputArr], { type: imageMimeType });
                    img.src = URL.createObjectURL(blob);
                    await new Promise((resolve, reject) => {
                        img.onload = resolve;
                        img.onerror = () => reject(new Error(`Failed to decode ${sourceFormat.toUpperCase()} source`));
                    });
                    canvas.width = img.width;
                    canvas.height = img.height;
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    ctx.drawImage(img, 0, 0);
                    sourceWidth = img.width;
                    sourceHeight = img.height;
                    URL.revokeObjectURL(img.src);
                }
                // 1c. JPEG JS Decoder
                else {
                    try {
                        const decoded = window['jpeg-js'].decode(inputArr, {
                            useTArray: true,
                            maxResolutionInMP: 260,
                            maxMemoryUsageInMB: 1024
                        });
                        canvas.width = decoded.width;
                        canvas.height = decoded.height;
                        ctx.putImageData(new ImageData(new Uint8ClampedArray(decoded.data), decoded.width, decoded.height), 0, 0);
                        sourceWidth = decoded.width;
                        sourceHeight = decoded.height;
                    } catch (e) {
                        throw new Error(`JPEG decode failed: ${e.message}`);
                    }
                }

                // 1. Phase 6: High Quality Downsample (Smart Oversample)
                if (payload.targetWidth && payload.targetHeight && (payload.targetWidth !== sourceWidth)) {
                    try {
                        canvas = downsample(canvas, payload.targetWidth, payload.targetHeight);
                    } catch (e) {
                        throw new Error(`Resizing failed: ${e.message}`);
                    }
                }

                // 2. Format Selection
                const requestedMaxBytes = payload.maxKB > 0 ? payload.maxKB * 1000 : Infinity;
                const targetBytes = payload.maxKB > 0 ? Math.floor(requestedMaxBytes * 0.99) : Infinity;
                let currentQuality = (payload.quality || 85) / 100;
                const mimeType = payload.format === "png" ? "image/png" :
                    (payload.format === "webp" ? "image/webp" : "image/jpeg");

                let dataUrl = "";
                let resultBase64 = "";
                let finalSize = 0;
                let warning = null;

                // 3. Encoding Logic: WASM vs Canvas
                const useMozJpeg = (payload.format === "jpg" || payload.format === "jpeg") && window.Codecs.mozjpeg;
                const useOxiPng = (payload.format === "png") && window.Codecs.oxipng;
                const useWebpEnc = (payload.format === "webp") && window.Codecs.webpenc;
                const isLossyTarget = payload.format === "jpg" || payload.format === "jpeg" || payload.format === "webp";

                // Encode using the most appropriate engine for the current phase
                const encodeStep = async (targetCanvas, q, forceNative = false, fastPng = false, targetSizeOverride = 0) => {
                    if (useMozJpeg && !forceNative) {
                        const raw = targetCanvas.getContext("2d").getImageData(0, 0, targetCanvas.width, targetCanvas.height).data;
                        const bytes = window.Codecs.encodeMozJpeg(raw, targetCanvas.width, targetCanvas.height, Math.round(q * 100));
                        return arrToB64(bytes);
                    } else if (useWebpEnc && !forceNative) {
                        const raw = targetCanvas.getContext("2d").getImageData(0, 0, targetCanvas.width, targetCanvas.height).data;
                        const bytes = window.Codecs.encodeWebp(raw, targetCanvas.width, targetCanvas.height, Math.round(q * 100), targetSizeOverride);
                        return arrToB64(bytes);
                    } else if (useOxiPng && !forceNative) {
                        const raw = targetCanvas.getContext("2d").getImageData(0, 0, targetCanvas.width, targetCanvas.height).data;
                        const bytes = await window.Codecs.optimiseOxiPng(raw, targetCanvas.width, targetCanvas.height, fastPng ? 0 : 2);
                        return arrToB64(bytes);
                    } else {
                        // Use native browser encoding as a fallback or as a fast intermediate check for PNG
                        const dataUrl = targetCanvas.toDataURL(mimeType, q);
                        return dataUrl.split(",")[1];
                    }
                };

                const encodeLossyToTarget = async (targetCanvas, startQuality) => {
                    const minQuality = payload.format === "webp" ? 0.01 : 0.05;
                    let bestBase64 = "";
                    let bestSize = Infinity;
                    let low = minQuality;
                    let high = Math.max(startQuality, minQuality);

                    const tryQuality = async (q) => {
                        checkCancel();
                        sendHeartbeat(requestId);
                        postToHost("progress", null, { message: `Optimizing... Quality: ${Math.round(q * 100)}%` });
                        const encodedBase64 = await encodeStep(targetCanvas, q, false, false, payload.format === "webp" ? targetBytes : 0);
                        const encodedSize = getByteSize(encodedBase64);
                        if (encodedSize < bestSize) {
                            bestBase64 = encodedBase64;
                            bestSize = encodedSize;
                        }
                        return { base64: encodedBase64, size: encodedSize, quality: q };
                    };

                    const highAttempt = await tryQuality(high);
                    if (highAttempt.size <= targetBytes) {
                        return { base64: highAttempt.base64, size: highAttempt.size };
                    }

                    const lowAttempt = await tryQuality(low);
                    if (lowAttempt.size > targetBytes) {
                        return { base64: lowAttempt.base64, size: lowAttempt.size };
                    }

                    let bestUnder = lowAttempt;

                    for (let i = 0; i < 7; i++) {
                        const q = (low + high) / 2;
                        const attempt = await tryQuality(q);
                        if (attempt.size <= targetBytes) {
                            bestUnder = attempt;
                            low = q;
                        } else {
                            high = q;
                        }
                    }

                    return { base64: bestUnder.base64, size: bestUnder.size };
                };

                // 3. Iterative Quality Compression (Lossy Formats Only)
                if (payload.maxKB > 0 && isLossyTarget) {
                    const lossyResult = await encodeLossyToTarget(canvas, currentQuality);
                    resultBase64 = lossyResult.base64;
                    finalSize = lossyResult.size;
                } else {
                    // Initial pass. Use OxiPNG immediately if available for PNG.
                    resultBase64 = await encodeStep(canvas, currentQuality);
                    finalSize = getByteSize(resultBase64);
                }

                // 4. Iterative Resize Sizing (Reverted to Original Logic)
                // If the target KB is not met, reduce dimensions by 15% iteratively.
                // This happens in memory without writing files to disk.
                if (finalSize > targetBytes) {
                    let scale = 0.85;
                    let currentIterationCanvas = canvas;
                    let lastSize = finalSize;

                    while (finalSize > targetBytes && scale >= 0.05) {
                        checkCancel();
                        sendHeartbeat(requestId);
                        const msg = `Shrinking size... (${Math.round(scale * 100)}%)`;
                        postToHost("progress", null, { message: msg });

                        currentIterationCanvas = downsample(canvas, Math.floor(canvas.width * scale), Math.floor(canvas.height * scale));

                        // Use fast optimization level for intermediate size checks
                        resultBase64 = await encodeStep(currentIterationCanvas, 0.1, false, true);
                        finalSize = getByteSize(resultBase64);

                        // Prevent infinite loops if file size stops decreasing
                        if (lastSize - finalSize < (targetBytes * 0.01)) break;
                        lastSize = finalSize;
                        scale *= 0.85; // Original reduction logic
                    }

                    canvas = currentIterationCanvas;
                    // Re-run quality targeting on the resolved dimensions so the final file still respects maxKB.
                    if (payload.maxKB > 0 && isLossyTarget) {
                        const lossyResult = await encodeLossyToTarget(canvas, currentQuality);
                        resultBase64 = lossyResult.base64;
                        finalSize = lossyResult.size;
                    } else {
                        resultBase64 = await encodeStep(canvas, currentQuality);
                        finalSize = getByteSize(resultBase64);
                    }
                }

                // 5. Final Warning Check
                if (finalSize > requestedMaxBytes && payload.maxKB > 0) {
                    warning = `Could not reach ${payload.maxKB}KB limit. Final size: ${Math.ceil(finalSize / 1000)}KB`;
                }

                postToHost("process-image-result", requestId, {
                    ok: true,
                    outputBase64: resultBase64,
                    warning: warning,
                    info: {
                        sourceWidth,
                        sourceHeight,
                        sourceBytes: inputArr.length,
                        width: canvas.width,
                        height: canvas.height,
                        format: payload.format
                    }
                });

                // Cleanup: Clear the main processing canvas to release memory
                if (ctx) {
                    ctx.clearRect(0, 0, canvas.width, canvas.height);
                    canvas.width = 1; // Set to minimal size instead of 0 for stability
                    canvas.height = 1;
                }
                // Final GC hint
                resultBase64 = null;

                break;

            default:
                console.warn(`Unknown request type: ${type}`);
        }
    } catch (err) {
        postToHost(`${type}-result`, requestId, { ok: false, error: err.message });
    }
}

window.addEventListener("message", handleRequest);

// Signal readiness to the host
postToHost("webview-ready", null);
