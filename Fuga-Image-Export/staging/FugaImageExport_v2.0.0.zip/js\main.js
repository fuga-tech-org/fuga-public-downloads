const { WebViewBridge } = require("./js/bridge.js");
const hostBridge = require("./js/host-bridge.js");
const supportLog = require("./js/support-log.js");

document.addEventListener("DOMContentLoaded", () => {
  supportLog.info("panel_loaded", {
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : ""
  }, { pinned: true });

  const codecWebview = document.getElementById("image-engine-webview");
  let codecBridge = null;
  if (codecWebview) {
    codecBridge = new WebViewBridge(codecWebview, 30000, (event) => {
      if (event.type === "progress") hostBridge.setStatusDetail(event.payload.message);
    });
    supportLog.info("webview_bridge_created", { timeoutMs: 30000 });
  } else {
    supportLog.warn("webview_missing", {});
  }

  const exportUiWebview = document.getElementById("export-ui");
  hostBridge.init(exportUiWebview, codecBridge);
});
