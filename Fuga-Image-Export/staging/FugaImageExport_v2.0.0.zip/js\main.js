const hostBridge = require("./js/host-bridge.js");
const supportLog = require("./js/support-log.js");

const PROBE_TIMEOUT_MS = 8000;

// Entry point: wires up the host<->export-ui message bridge (so the page can
// start sending "ready" as soon as its own script runs), then the export-ui
// error overlay. There's no codec webview here at all anymore — the page
// creates and owns its own codec engine internally (its own webview/iframe),
// relaying processing requests over the same {action, ...} channel as
// everything else. See host-bridge.js's sendProcessImageRequest.
document.addEventListener("DOMContentLoaded", () => {
  supportLog.info("panel_loaded", {
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : ""
  }, { pinned: true });

  const exportUiWebview = document.getElementById("export-ui");

  hostBridge.init(exportUiWebview);
  bindExportUiErrorOverlay(exportUiWebview);
});

// Probes a URL with fetch() before ever navigating a webview to it, so a
// down/unreachable server never gets the chance to render the browser
// engine's own native error page inside the panel. Resolves true/false.
function probeUrl(url) {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), PROBE_TIMEOUT_MS);
  return fetch(url, { mode: "no-cors", cache: "no-store", signal: controller.signal })
    .then(() => true)
    .catch(() => false)
    .finally(() => clearTimeout(timeoutId));
}

// ── EXPORT-UI CONNECTION ─────────────────────────────────────────
// The webview only ever navigates here, never from the static markup
// (index.html deliberately uses data-src, not src). A failed navigation
// (DNS error, connection refused, unreachable host) still renders the
// browser engine's own native error page and fires an ordinary "loadstop",
// not "loaderror" — so waiting for loaderror lets that native page slip
// through. Probing reachability with fetch() first avoids that: the
// webview's src is only ever set once the target has already answered.
// Mirrors client/codesigner/loader.js in fuga-illustrator-plugins.
function bindExportUiErrorOverlay(webview) {
  if (!webview) return;
  const overlay = document.getElementById("export-ui-error");
  const detailEl = document.getElementById("export-ui-error-detail");
  const retryBtn = document.getElementById("export-ui-retry");
  if (!overlay || !retryBtn) return;

  const targetUrl = webview.getAttribute("data-src");
  if (!targetUrl) {
    supportLog.warn("export_ui_missing_data_src", {});
    return;
  }

  let attempt = 0;

  // Shows the overlay with an optional detail line explaining the failure.
  function showError(detail) {
    if (detailEl) detailEl.textContent = detail || "";
    overlay.classList.add("visible");
  }

  // Hides the overlay once the page is confirmed loading/loaded.
  function hideError() {
    overlay.classList.remove("visible");
  }

  // Probes then (if reachable) navigates the webview. Each call captures its
  // own attempt number so that a stale probe from an earlier click (e.g. the
  // user mashing Retry) can't clobber a newer attempt's result once it
  // resolves out of order.
  function loadExportUi() {
    const thisAttempt = ++attempt;
    hideError();

    probeUrl(targetUrl).then((reachable) => {
      if (thisAttempt !== attempt) return;
      if (!reachable) {
        supportLog.warn("export_ui_probe_failed", { url: targetUrl }, { pinned: true });
        showError("Check your internet connection and try again.");
        return;
      }
      webview.src = targetUrl;
    });
  }

  // Backstop for the rarer case where the probe succeeds but the real
  // navigation still fails (e.g. redirected into an error afterward).
  webview.addEventListener("loaderror", (e) => {
    supportLog.warn("export_ui_load_error", { url: e.url, code: e.code, message: e.message }, { pinned: true });
    showError(e.message ? `${e.message} (${e.code})` : "");
  });
  // A successful navigation clears any overlay left over from a prior failed attempt.
  webview.addEventListener("loadstop", () => {
    if (webview.src) hideError();
  });

  // Manual retry re-runs the full probe-then-navigate flow from scratch.
  retryBtn.addEventListener("click", () => {
    supportLog.info("export_ui_retry_clicked", {});
    loadExportUi();
  });

  loadExportUi();
}
