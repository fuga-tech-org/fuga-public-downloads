const nacl = require("./vendor/tweetnacl.min.js");

const PRODUCT_ID = "com.fuga.imageexport";
const PUBLIC_KEY_B64 = "Aw4p4mRotnMYYxhXmhivj4uaShROuwuXibflCdmuz4A=";
const LICENSE_TIME_URL = "https://dev-stage.fugaw2p.com/uxp_export_lic/beta_time.php";

function getStorage() { return require("uxp").storage; }

function b64ToArr(str) {
  if (typeof atob === "function") {
    const bin = atob(str);
    const out = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i);
    return out;
  }
  return new Uint8Array(Buffer.from(str, "base64"));
}

function encodeUtf8(str) {
  if (typeof TextEncoder !== "undefined") return new TextEncoder().encode(str);

  const bytes = [];
  for (let i = 0; i < str.length; i++) {
    let codePoint = str.charCodeAt(i);
    if (codePoint >= 0xd800 && codePoint <= 0xdbff && i + 1 < str.length) {
      const next = str.charCodeAt(i + 1);
      if (next >= 0xdc00 && next <= 0xdfff) {
        codePoint = 0x10000 + ((codePoint - 0xd800) << 10) + (next - 0xdc00);
        i++;
      }
    }

    if (codePoint < 0x80) bytes.push(codePoint);
    else if (codePoint < 0x800) {
      bytes.push(0xc0 | (codePoint >> 6));
      bytes.push(0x80 | (codePoint & 0x3f));
    } else if (codePoint < 0x10000) {
      bytes.push(0xe0 | (codePoint >> 12));
      bytes.push(0x80 | ((codePoint >> 6) & 0x3f));
      bytes.push(0x80 | (codePoint & 0x3f));
    } else {
      bytes.push(0xf0 | (codePoint >> 18));
      bytes.push(0x80 | ((codePoint >> 12) & 0x3f));
      bytes.push(0x80 | ((codePoint >> 6) & 0x3f));
      bytes.push(0x80 | (codePoint & 0x3f));
    }
  }
  return new Uint8Array(bytes);
}

function stableStringify(value) {
  if (value === null || typeof value !== "object") return JSON.stringify(value);
  if (Array.isArray(value)) return "[" + value.map(stableStringify).join(",") + "]";

  const keys = Object.keys(value).sort();
  return "{" + keys.map(key => JSON.stringify(key) + ":" + stableStringify(value[key])).join(",") + "}";
}

function verifySignedPayload(doc) {
  if (!doc || !doc.payload || !doc.signature) {
    return { ok: false, message: "Signed document is missing required fields." };
  }

  const publicKey = b64ToArr(PUBLIC_KEY_B64);
  const signature = b64ToArr(doc.signature);
  const message = encodeUtf8(stableStringify(doc.payload));
  const validSignature = nacl.sign.detached.verify(message, signature, publicKey);
  if (!validSignature) {
    return { ok: false, message: "Signature is invalid." };
  }

  return { ok: true, payload: doc.payload };
}

async function readBundledLicense() {
  const pluginFolder = await getStorage().localFileSystem.getPluginFolder();
  const licenseFile = await pluginFolder.getEntry("license.json");
  const text = await licenseFile.read();
  return JSON.parse(text);
}

function parseDate(value, label) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return { ok: false, message: `${label} date is invalid.` };
  }
  return { ok: true, date };
}

function resolveEffectiveExpiry(localExpiresAt, serverExpiresAt = null) {
  const local = parseDate(localExpiresAt, "License expiry");
  if (!local.ok) return local;

  if (!serverExpiresAt) return { ok: true, date: local.date };

  const server = parseDate(serverExpiresAt, "Server expiry");
  if (!server.ok) return server;

  return {
    ok: true,
    date: server.date < local.date ? server.date : local.date
  };
}

function verifyLicenseDocument(doc, now = new Date(), serverExpiresAt = null) {
  const signed = verifySignedPayload(doc);
  if (!signed.ok) {
    return { ok: false, message: signed.message.replace("Signed document", "License file") };
  }

  const payload = signed.payload;
  if (payload.product !== PRODUCT_ID) {
    return { ok: false, message: "License is for a different product." };
  }

  const effectiveExpiry = resolveEffectiveExpiry(payload.expiresAt, serverExpiresAt);
  if (!effectiveExpiry.ok) return { ok: false, message: effectiveExpiry.message };

  if (now > effectiveExpiry.date) {
    return {
      ok: false,
      expired: true,
      message: "This beta license has expired. Please contact Fuga-Tech support.",
      payload,
      effectiveExpiresAt: effectiveExpiry.date.toISOString()
    };
  }

  return { ok: true, message: "License is valid.", payload, effectiveExpiresAt: effectiveExpiry.date.toISOString() };
}

async function fetchTrustedServerTime() {
  if (!LICENSE_TIME_URL) {
    return { ok: false, skipped: true, message: "Online time endpoint is not configured." };
  }

  if (typeof fetch !== "function") {
    return { ok: false, message: "Online time check is unavailable in this runtime." };
  }

  const response = await fetch(LICENSE_TIME_URL, { cache: "no-store" });
  if (!response.ok) {
    return { ok: false, message: `Online time check failed: HTTP ${response.status}` };
  }

  const signed = verifySignedPayload(await response.json());
  if (!signed.ok) {
    return { ok: false, message: `Online time check failed: ${signed.message}` };
  }

  if (signed.payload.product !== PRODUCT_ID) {
    return { ok: false, message: "Online time response is for a different product." };
  }

  const serverTime = new Date(signed.payload.serverTime);
  if (Number.isNaN(serverTime.getTime())) {
    return { ok: false, message: "Online time response has an invalid date." };
  }

  const serverExpiry = parseDate(signed.payload.expiresAt, "Online expiry");
  if (!serverExpiry.ok) {
    return { ok: false, message: `Online time response has an invalid expiry date.` };
  }

  return { ok: true, serverTime, expiresAt: signed.payload.expiresAt };
}

async function resolveTrustedNow() {
  const online = await fetchTrustedServerTime();
  if (online.ok) {
    return { ok: true, now: online.serverTime, source: "online", serverExpiresAt: online.expiresAt };
  }

  if (online.skipped) {
    return { ok: true, now: new Date(), source: "local" };
  }

  return { ok: false, message: online.message };
}

async function checkLicense() {
  try {
    const doc = await readBundledLicense();
    const signed = verifySignedPayload(doc);
    if (!signed.ok) {
      return { ok: false, message: signed.message.replace("Signed document", "License file") };
    }

    const time = await resolveTrustedNow();
    if (!time.ok) return time;

    const result = verifyLicenseDocument(doc, time.now, time.serverExpiresAt);
    result.timeSource = time.source;
    return result;
  } catch (err) {
    return { ok: false, message: `License check failed: ${err.message}` };
  }
}

module.exports = {
  checkLicense,
  stableStringify,
  verifySignedPayload,
  verifyLicenseDocument
};
