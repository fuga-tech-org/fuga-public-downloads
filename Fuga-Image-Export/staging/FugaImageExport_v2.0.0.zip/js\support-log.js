const MAX_ENTRIES = 2000;
const MAX_PINNED_ENTRIES = 200;
const STORAGE_KEY = "fuga.imageexport.supportLog";

const sessionId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
let entries = [];

function safeStringify(value) {
  try {
    return JSON.stringify(value);
  } catch (err) {
    return JSON.stringify({ stringifyError: err.message });
  }
}

function loadStoredEntries() {
  try {
    if (typeof localStorage === "undefined") return;
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return;
    const parsed = JSON.parse(stored);
    if (Array.isArray(parsed)) entries = trimEntries(parsed);
  } catch (err) {
    entries = [];
  }
}

// Pinned entries (session/environment context, temp-folder selection, fatal
// errors) survive the ring buffer even once per-page volume pushes past
// MAX_ENTRIES, since those are exactly the fields needed to diagnose a
// customer's temp-file issue and are otherwise the first to get evicted.
function trimEntries(list) {
  const pinned = list.filter(e => e.pinned).slice(-MAX_PINNED_ENTRIES);
  const unpinned = list.filter(e => !e.pinned);
  const keepUnpinnedCount = Math.max(0, MAX_ENTRIES - pinned.length);
  const trimmedUnpinned = unpinned.slice(-keepUnpinnedCount);
  return pinned.concat(trimmedUnpinned).sort((a, b) => (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : 0));
}

function persist() {
  try {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch (err) {
    // Logging must never interrupt plugin behavior.
  }
}

function write(level, event, data = {}, options = {}) {
  const entry = {
    ts: new Date().toISOString(),
    sessionId,
    level,
    event,
    data,
    pinned: !!options.pinned
  };

  entries.push(entry);
  entries = trimEntries(entries);
  persist();

  const message = `[Fuga Image Export][${level}] ${event}`;
  if (level === "error") console.error(message, data);
  else if (level === "warn") console.warn(message, data);
  else console.log(message, data);
}

function info(event, data, options) {
  write("info", event, data, options);
}

function warn(event, data, options) {
  write("warn", event, data, options);
}

function error(event, data, options) {
  write("error", event, data, options);
}

function clear() {
  entries = [];
  persist();
}

function getEntries() {
  return entries.slice();
}

function getText() {
  const lines = [
    "Fuga Image Export Support Log",
    `Generated: ${new Date().toISOString()}`,
    `Session: ${sessionId}`,
    ""
  ];

  for (const entry of entries) {
    lines.push(`${entry.ts} [${entry.level.toUpperCase()}] ${entry.event} ${safeStringify(entry.data)}`);
  }

  return lines.join("\n") + "\n";
}

loadStoredEntries();

module.exports = {
  clear,
  error,
  getEntries,
  getText,
  info,
  warn
};
