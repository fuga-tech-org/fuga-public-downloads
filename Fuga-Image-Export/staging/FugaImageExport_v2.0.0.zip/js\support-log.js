const MAX_ENTRIES = 2000;
const MAX_PINNED_ENTRIES = 200;
const STORAGE_KEY = "fuga.imageexport.supportLog";

const sessionId = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
let entries = [];

// JSON.stringify that can't throw — a log call must never itself crash the
// plugin (e.g. on a circular-reference payload), so a stringify failure is
// captured as log data instead of propagating.
function safeStringify(value) {
  try {
    return JSON.stringify(value);
  } catch (err) {
    return JSON.stringify({ stringifyError: err.message });
  }
}

// Restores the in-memory log from localStorage on module load, so a support
// log started before a panel reload isn't lost. Any corruption/absence is
// treated as "start empty" rather than an error.
function loadStoredEntries() {
  try {
    if (typeof localStorage === "undefined") return;
    const stored = localStorage.getItem(STORAGE_KEY);
    if (!stored) return;
    const parsed = JSON.parse(stored);
    if (Array.isArray(parsed)) entries = trimEntries(parsed);
  } catch (err) {
    entries = [];
  }
}

// Pinned entries (session/environment context, temp-folder selection, fatal
// errors) survive the ring buffer even once per-page volume pushes past
// MAX_ENTRIES, since those are exactly the fields needed to diagnose a
// customer's temp-file issue and are otherwise the first to get evicted.
function trimEntries(list) {
  const pinned = list.filter(e => e.pinned).slice(-MAX_PINNED_ENTRIES);
  const unpinned = list.filter(e => !e.pinned);
  const keepUnpinnedCount = Math.max(0, MAX_ENTRIES - pinned.length);
  const trimmedUnpinned = unpinned.slice(-keepUnpinnedCount);
  return pinned.concat(trimmedUnpinned).sort((a, b) => (a.ts < b.ts ? -1 : a.ts > b.ts ? 1 : 0));
}

// Writes the current entry buffer to localStorage so it survives a panel
// reload; failures (e.g. quota exceeded) are swallowed for the same reason
// as above — logging is never allowed to break the plugin.
function persist() {
  try {
    if (typeof localStorage === "undefined") return;
    localStorage.setItem(STORAGE_KEY, JSON.stringify(entries));
  } catch (err) {
    // Logging must never interrupt plugin behavior.
  }
}

// Core log-entry constructor: appends to the ring buffer, persists, and
// mirrors to the devtools console at the matching level.
function write(level, event, data = {}, options = {}) {
  const entry = {
    ts: new Date().toISOString(),
    sessionId,
    level,
    event,
    data,
    pinned: !!options.pinned
  };

  entries.push(entry);
  entries = trimEntries(entries);
  persist();

  const message = `[Fuga Image Export][${level}] ${event}`;
  if (level === "error") console.error(message, data);
  else if (level === "warn") console.warn(message, data);
  else console.log(message, data);
}

// Logs an informational event.
function info(event, data, options) {
  write("info", event, data, options);
}

// Logs a warning event.
function warn(event, data, options) {
  write("warn", event, data, options);
}

// Logs an error event.
function error(event, data, options) {
  write("error", event, data, options);
}

// Renders the full log as plain text for writing out to the support log file.
function getText() {
  const lines = [
    "Fuga Image Export Support Log",
    `Generated: ${new Date().toISOString()}`,
    `Session: ${sessionId}`,
    ""
  ];

  for (const entry of entries) {
    lines.push(`${entry.ts} [${entry.level.toUpperCase()}] ${entry.event} ${safeStringify(entry.data)}`);
  }

  return lines.join("\n") + "\n";
}

// Populate `entries` from any prior session immediately on module load.
loadStoredEntries();

module.exports = {
  error,
  getText,
  info,
  warn
};
