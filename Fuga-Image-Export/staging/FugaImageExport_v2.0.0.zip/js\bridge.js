/**
 * Orchestrates communication between the UXP Host and the WebView
 */
class WebViewBridge {
    constructor(webviewElement, timeoutMs = 30000, onEvent = null) {
        this.webview = webviewElement;
        this.timeoutMs = timeoutMs;
        this.pendingRequests = new Map();
        this.isReady = false;
        this.onEvent = onEvent; // Callback for non-request messages (like progress/logs)
        this._handshakeTimer = null;

        window.addEventListener("message", (event) => {
            this._handleResponse(event.data);
        });

        this._startHandshake();
    }

    /**
     * Sends a request and returns a Promise that resolves with the payload
     */
    sendRequest(type, payload = {}) {
        if (!this.isReady && type !== "ping") {
            throw new Error("Bridge is not ready. Wait for 'webview-ready'.");
        }

        const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
        
        const promise = new Promise((resolve, reject) => {
            const timeout = setTimeout(() => {
                if (this.pendingRequests.has(requestId)) {
                    this.pendingRequests.delete(requestId);
                    reject(new Error(`Request ${type} (ID: ${requestId}) timed out after ${this.timeoutMs}ms`));
                }
            }, this.timeoutMs);

            this.pendingRequests.set(requestId, { resolve, reject, timeout });

            this.webview.postMessage({
                type,
                requestId,
                payload
            }, "*");
        });

        promise.requestId = requestId;
        return promise;
    }

    /**
     * Signals the webview to stop the current processing task
     */
    cancelRequest(requestId) {
        console.log(`WebView Bridge: Sending cancel for ${requestId}`);
        this.webview.postMessage({ type: "cancel-request", requestId }, "*");
    }

    _startHandshake() {
        let attempts = 0;
        const maxAttempts = 20;

        const tryPing = async () => {
            if (this.isReady || attempts >= maxAttempts) {
                if (this._handshakeTimer) {
                    clearInterval(this._handshakeTimer);
                    this._handshakeTimer = null;
                }
                return;
            }

            attempts += 1;
            try {
                await this.sendRequest("ping");
                this.isReady = true;
                console.log("WebView Bridge: Connected via ping");
                if (this._handshakeTimer) {
                    clearInterval(this._handshakeTimer);
                    this._handshakeTimer = null;
                }
            } catch (error) {
                // Keep retrying until the webview has finished loading.
            }
        };

        tryPing();
        this._handshakeTimer = setInterval(tryPing, 500);
    }

    _handleResponse(data) {
        if (!data || !data.type) return;

        // Handle internal handshake
        if (data.type === "webview-ready") {
            this.isReady = true;
            console.log("WebView Bridge: Connected");
            return;
        }

        if (data.type === "ping-result") {
            this.isReady = true;
        }

        // Handle heartbeats to prevent timeouts during long tasks
        if (data.type === "heartbeat" && data.requestId) {
            const request = this.pendingRequests.get(data.requestId);
            if (request) {
                clearTimeout(request.timeout);
                request.timeout = setTimeout(() => {
                    if (this.pendingRequests.has(data.requestId)) {
                        this.pendingRequests.delete(data.requestId);
                        request.reject(new Error(`Request ${data.requestId} timed out after extension`));
                    }
                }, this.timeoutMs);
            }
            return;
        }

        // Handle general events (progress, logs, etc)
        if (!data.requestId && this.onEvent) {
            this.onEvent(data);
        }

        const request = this.pendingRequests.get(data.requestId);
        if (request) {
            clearTimeout(request.timeout);
            this.pendingRequests.delete(data.requestId);

            if (data.payload && data.payload.ok === false) {
                request.reject(new Error(data.payload.error || "Unknown WebView error"));
            } else {
                request.resolve(data.payload);
            }
        }
    }
}

module.exports = { WebViewBridge };
