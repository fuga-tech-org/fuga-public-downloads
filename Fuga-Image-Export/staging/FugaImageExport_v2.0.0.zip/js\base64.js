/**
 * Base64 conversion utilities for UXP (Host side)
 * Optimized for performance in the UXP environment
 */

function arrToB64(uint8) {
    let b64 = "";
    const chunk = 8192;
    for (let i = 0; i < uint8.length; i += chunk) {
        b64 += String.fromCharCode.apply(null, uint8.subarray(i, i + chunk));
    }
    return btoa(b64);
}

function b64ToArr(str) {
    const bin = atob(str);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
        buf[i] = bin.charCodeAt(i);
    }
    return buf;
}

module.exports = { arrToB64, b64ToArr };