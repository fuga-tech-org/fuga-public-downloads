/**
 * Base64 conversion utilities for UXP (Host side)
 * Optimized for performance in the UXP environment
 */

// Encodes bytes to base64. Chunks the input before String.fromCharCode.apply()
// because passing a very large array as spread arguments can blow the JS
// engine's call-stack/argument-count limit — 8192 stays safely under that.
function arrToB64(uint8) {
    let b64 = "";
    const chunk = 8192;
    for (let i = 0; i < uint8.length; i += chunk) {
        b64 += String.fromCharCode.apply(null, uint8.subarray(i, i + chunk));
    }
    return btoa(b64);
}

// Decodes a base64 string back to raw bytes.
function b64ToArr(str) {
    const bin = atob(str);
    const buf = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) {
        buf[i] = bin.charCodeAt(i);
    }
    return buf;
}

module.exports = { arrToB64, b64ToArr };