/**
 * WASM Codec Loader and Wrappers
 */

window.Codecs = {
    mozjpeg: null,
    oxipng: null,
    webpdec: null,
    webpenc: null,

    async initMozJpeg() {
        if (this.mozjpeg) return;
        try {
            // This assumes you have the Emscripten-generated JS/WASM 
            // from the Squoosh MozJPEG build.
            const Module = await window.loadMozJpegWasm(); 
            this.mozjpeg = Module;
            console.log("MozJPEG WASM Initialized");
        } catch (e) {
            console.error("Failed to load MozJPEG WASM:", e);
        }
    },

    async initOxiPng() {
        if (this.oxipng) return;
        try {
            // The OxiPNG glue usually exports 'init' as default and functions as names.
            // We need to ensure we capture the JS wrapper function, not just the raw WASM.
            if (typeof window.squoosh_oxipng_init !== 'function') {
                 throw new Error("OxiPNG glue not found. Check script loading.");
            }
            this.oxipng = await window.loadOxiPngWasm();
            console.log("OxiPNG WASM Initialized");
        } catch (e) {
            console.error("Failed to load OxiPNG WASM:", e);
        }
    },

    async initWebpDec() {
        if (this.webpdec) return;
        try {
            const Module = await window.loadWebpDecWasm();
            this.webpdec = Module;
            console.log("WebP Decoder WASM Initialized");
        } catch (e) {
            console.error("Failed to load WebP Decoder WASM:", e);
        }
    },

    async initWebpEnc() {
        if (this.webpenc) return;
        try {
            const Module = await window.loadWebpEncWasm();
            this.webpenc = Module;
            console.log("WebP Encoder WASM Initialized");
        } catch (e) {
            console.error("Failed to load WebP Encoder WASM:", e);
        }
    },

    encodeMozJpeg(pixels, width, height, quality) {
        if (!this.mozjpeg) throw new Error("MozJPEG not initialized");

        const options = {
            quality: quality,
            baseline: false,
            arithmetic: false,
            progressive: true,
            optimize_coding: true,
            smoothing: 0,
            color_space: 3, // YCbCr
            quant_table: 3,
            trellis_multipass: false,
            trellis_opt_zero: false,
            trellis_opt_table: false,
            trellis_loops: 1,
            auto_subsample: true,
            chroma_subsample: 2,
            separate_chroma_quality: false,
            chroma_quality: quality
        };

        // The encode function bound in mozjpeg_enc.cpp
        const result = this.mozjpeg.encode(pixels, width, height, options);
        return result;
    },

    async optimiseOxiPng(pixels, width, height, level = 2) {
        // We must call the JS wrapper 'optimise', not the raw wasm.optimise.
        // This assumes the function was made global in squoosh_oxipng.js or captured during init.
        if (typeof window.oxipng_optimise !== 'function') {
            throw new Error("OxiPNG wrapper function not found.");
        }
        
        // Squoosh OxiPNG expects a Uint8ClampedArray (RGBA)
        return window.oxipng_optimise(pixels, width, height, level, false);
    },

    encodeWebp(pixels, width, height, quality, targetSize = 0) {
        if (!this.webpenc) throw new Error("WebP encoder not initialized");

        const options = {
            quality: quality,
            target_size: targetSize,
            target_PSNR: 0,
            method: targetSize > 0 ? 6 : 4,
            sns_strength: 50,
            filter_strength: 20,
            filter_sharpness: 0,
            filter_type: 0,
            partitions: 0,
            segments: 4,
            pass: targetSize > 0 ? 6 : 1,
            show_compressed: 0,
            preprocessing: 0,
            autofilter: targetSize > 0 ? 1 : 0,
            partition_limit: 0,
            alpha_compression: 1,
            alpha_filtering: 1,
            alpha_quality: 100,
            lossless: 0,
            exact: 0,
            image_hint: this.webpenc.WebPImageHint.WEBP_HINT_GRAPH,
            emulate_jpeg_size: 0,
            thread_level: 1,
            low_memory: 0,
            near_lossless: 100,
            use_delta_palette: 0,
            use_sharp_yuv: 0
        };

        return this.webpenc.encode(pixels, width, height, options);
    }
};

/**
 * Real loader for the MozJPEG Emscripten module.
 * This expects mozjpeg_enc.js to be loaded via <script> tag, 
 * which defines a 'mozjpeg' factory function.
 */
window.loadMozJpegWasm = async function() {
    if (typeof window.mozjpeg !== 'function') {
        throw new Error("mozjpeg_enc.js not loaded. Ensure it is included in index.html");
    }
    
    // Instantiate the Emscripten module (returns a Promise)
    return await window.mozjpeg();
};

/**
 * Loader for OxiPNG
 */
window.loadOxiPngWasm = async function() {
    if (typeof window.squoosh_oxipng_init !== 'function') {
        throw new Error("oxipng_init not found");
    }
    return await window.squoosh_oxipng_init({
        locateFile: (path) => path.endsWith('.wasm') ? 'codecs/squoosh_oxipng_bg.wasm' : path
    });
};

/**
 * Loader for WebP Decoder
 */
window.loadWebpDecWasm = async function() {
    if (typeof window.webp_dec !== 'function') {
        throw new Error("webp_dec glue not loaded");
    }
    return await window.webp_dec({
        locateFile: (path) => path.endsWith('.wasm') ? 'codecs/webp_dec.wasm' : path
    });
};

/**
 * Loader for WebP Encoder
 */
window.loadWebpEncWasm = async function() {
    const moduleNs = await import('./codecs/webp_enc.js');
    const factory = moduleNs && moduleNs.default ? moduleNs.default : moduleNs;
    if (typeof factory !== 'function') {
        throw new Error("webp_enc module factory not found");
    }
    return await factory({
        locateFile: (path) => path.endsWith('.wasm') ? 'codecs/webp_enc.wasm' : path
    });
};
