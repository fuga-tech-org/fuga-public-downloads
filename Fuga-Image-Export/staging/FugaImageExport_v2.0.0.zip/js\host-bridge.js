/**
 * Action-message bridge between the UXP host and the export-ui webview
 * (the web2print page). Owns everything only InDesign/UXP can do: document
 * access, temp-file I/O, and export orchestration. The page owns the form UI
 * and sends/receives plain {action, ...} messages — see
 * docs/migration/MIGRATION_PLAN.md for the action table.
 */
const { app, ExportFormat, ExportRangeOrAllPages, JPEGOptionsQuality, SaveOptions, LocationOptions } = require("indesign");
const base64 = require("./base64.js");
const supportLog = require("./support-log.js");

// Shorthand accessor for the UXP local file system module.
function getFS() { return require("uxp").storage.localFileSystem; }
// Shorthand accessor for the UXP storage module (formats, fs helpers, etc).
function getStorage() { return require("uxp").storage; }

// Hard safety ceiling — never exceeded regardless of what the page requests
// via settings.maxSourceMp, to protect against a bad web-side config causing
// memory pressure. This is the one number that genuinely needs a plugin
// update to raise; everything else below is page-tunable up to it.
const HARD_MAX_PROCESSING_SOURCE_MP = 40;

// Fallback defaults, used only when the page doesn't send its own values —
// keeps this host working standalone/backward-compatibly. The page (see
// exportPanelMain.js) is the intended source of truth for these; edit them
// there, not here, to change behavior without a plugin update.
const DEFAULT_QUALITY_PERCENT = { low: 45, medium: 65, high: 80, maximum: 92 };
const DEFAULT_OVERSAMPLE_THRESHOLDS = [
  { maxShortPx: 600, mult: 4 },
  { maxShortPx: 1600, mult: 2 }
];
const DEFAULT_FILENAME_TEMPLATE = "{prefix}_{doc}_{size}_{page}_{suffix}";
const DEFAULT_MAX_SIZE_SUPPORTED_FORMATS = ["jpg", "webp"];
// The page owns the codec engine entirely now (its own webview/iframe,
// created and managed inside export_panel/index.php) — the host never talks
// to it directly. Every processing request is relayed through the same
// {action, ...} channel as everything else, with this timeout guarding each
// relayed request in case the page-side relay or its codec never responds.
const PROCESS_IMAGE_TIMEOUT_MS = 30000;

// Resolves the effective quality percent for lossy processed exports: an
// explicit numeric value from the page wins, otherwise fall back to the
// default for the named quality preset.
function resolveQualityPercent(settings) {
  const sent = Number(settings.qualityPercent);
  if (Number.isFinite(sent) && sent > 0) return sent;
  return DEFAULT_QUALITY_PERCENT[settings.quality] || DEFAULT_QUALITY_PERCENT.high;
}

// Resolves the oversample thresholds sent by the page, validating shape
// before trusting it; sorted ascending so getOversampleMult's first-match
// scan (smallest maxShortPx first) behaves correctly.
function resolveOversampleThresholds(settings) {
  const sent = settings.oversampleThresholds;
  if (Array.isArray(sent) && sent.length && sent.every(t => t && Number.isFinite(t.maxShortPx) && Number.isFinite(t.mult))) {
    return sent.slice().sort((a, b) => a.maxShortPx - b.maxShortPx);
  }
  return DEFAULT_OVERSAMPLE_THRESHOLDS;
}

// Resolves the max source-resolution cap (in megapixels) for this export,
// clamped to HARD_MAX_PROCESSING_SOURCE_MP no matter what the page requests.
function resolveMaxSourceMp(settings) {
  const sent = Number(settings.maxSourceMp);
  if (Number.isFinite(sent) && sent > 0) return Math.min(sent, HARD_MAX_PROCESSING_SOURCE_MP);
  return HARD_MAX_PROCESSING_SOURCE_MP;
}

// Resolves the filename template to use, falling back to the default when
// the page didn't send one (or sent an empty/whitespace-only string).
function resolveFilenameTemplate(settings) {
  return (typeof settings.filenameTemplate === "string" && settings.filenameTemplate.trim())
    ? settings.filenameTemplate
    : DEFAULT_FILENAME_TEMPLATE;
}

// Resolves which output formats a max-file-size cap applies to — a page-
// tunable list (e.g. once PNG size-targeting ships, the page can add "png"
// without a plugin update), falling back to the current jpg/webp-only rule.
function resolveMaxSizeSupportedFormats(settings) {
  const sent = settings.maxSizeSupportedFormats;
  if (Array.isArray(sent) && sent.length && sent.every(f => typeof f === "string")) {
    return sent;
  }
  return DEFAULT_MAX_SIZE_SUPPORTED_FORMATS;
}

// Fills a filename template's {token} placeholders from values, then
// collapses runs of "_" left behind by empty tokens (e.g. no prefix/suffix)
// and trims leading/trailing ones so disabled options don't leave stray
// underscores in the final name.
function applyFilenameTemplate(template, values) {
  const filled = template.replace(/\{(\w+)\}/g, (_, key) => (values[key] || ""));
  const collapsed = filled.replace(/_+/g, "_").replace(/^_+|_+$/g, "");
  return collapsed || values.doc || "export";
}

// Thrown to unwind an in-progress export when the user cancels mid-page;
// doExport's per-page catch treats this as a non-failure, not an error.
class ExportCancelledError extends Error {
  constructor(message = "Export cancelled") {
    super(message);
    this.name = "ExportCancelledError";
  }
}

let webview = null;
let isExporting = false;
let currentRequestId = null;
let outputFolderEntry = null;
let exportStatusBase = "";
let exportStatusDetail = "";

// Whether the page's own codec engine (its webview/iframe, entirely
// page-managed) has reported itself ready. Pushed by the page via a
// "codecStatus" message whenever it changes — the host has no direct
// connection to the codec at all, so this is the only signal it gets.
let codecReady = false;
// In-flight processImage relay, keyed by requestId — see
// sendProcessImageRequest()/handleProcessImageResult(). Only one request is
// ever in flight at a time (the codec processes one page at a time), but
// keying by requestId keeps a stale/duplicate response from resolving the
// wrong pending call.
const pendingProcessRequests = new Map();

// Entry point called once by main.js at startup: wires up the export-ui
// webview reference and registers the message listener.
function init(exportUiWebview) {
  webview = exportUiWebview;
  window.addEventListener("message", (e) => handleMessage(e.data));
}

// Relays a process-image request to the page over the existing action
// channel instead of talking to a codec webview directly — the page is
// responsible for forwarding this into its own codec engine and replying
// with processImageResult. Rejects on timeout so a page-side relay that
// never responds doesn't hang doExport forever.
function sendProcessImageRequest(payload) {
  const requestId = `req_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;

  const promise = new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      if (pendingProcessRequests.has(requestId)) {
        pendingProcessRequests.delete(requestId);
        reject(new Error(`processImage (ID: ${requestId}) timed out after ${PROCESS_IMAGE_TIMEOUT_MS}ms`));
      }
    }, PROCESS_IMAGE_TIMEOUT_MS);

    pendingProcessRequests.set(requestId, { resolve, reject, timeout });
    postToPage("processImage", Object.assign({ requestId }, payload));
  });

  promise.requestId = requestId;
  return promise;
}

// Resolves/rejects the pending processImage promise matching this
// response's requestId, if any (a stale/duplicate response is ignored).
function handleProcessImageResult(data) {
  const pending = pendingProcessRequests.get(data.requestId);
  if (!pending) return;
  clearTimeout(pending.timeout);
  pendingProcessRequests.delete(data.requestId);

  if (data.ok === false) {
    pending.reject(new Error(data.error || "Unknown processing error"));
  } else {
    pending.resolve(data);
  }
}

// Sends an {action, ...payload} message to the export-ui webview; a no-op
// if the webview hasn't been wired up yet.
function postToPage(action, payload) {
  if (!webview) return;
  webview.postMessage(Object.assign({ action }, payload || {}), "*");
}

// Updates the secondary status line (e.g. a per-step detail) and pushes the
// combined status to the page. Exported for use by other host modules.
function setStatusDetail(msg) {
  exportStatusDetail = msg || "";
  postProgress();
}

// Dispatches an incoming {action, ...} message from the export-ui page to
// the matching handler; unknown actions are silently ignored.
async function handleMessage(data) {
  if (!data || !data.action) return;

  switch (data.action) {
    case "ready":
      supportLog.info("export_ui_ready", {}, { pinned: true });
      postToPage("init", {
        version: getPanelVersion(),
        document: getDocumentInfoPayload()
      });
      break;
    case "getDocumentInfo":
      postToPage("documentInfo", getDocumentInfoPayload(data));
      break;
    case "browseFolder":
      await handleBrowseFolder();
      break;
    case "getSupportLogPath":
      postToPage("supportLogPath", { path: await resolveSupportLogPath() });
      break;
    case "runExport":
      await handleRunExport(data);
      break;
    case "cancelExport":
      handleCancelExport();
      break;
    // Pushed whenever the page's own codec engine's ready state changes —
    // the host has no direct connection to it, this is the only signal.
    case "codecStatus":
      codecReady = !!data.ready;
      supportLog.info("codec_status_changed", { ready: codecReady }, { pinned: true });
      break;
    // Reply to a processImage request relayed via sendProcessImageRequest().
    case "processImageResult":
      handleProcessImageResult(data);
      break;
    // Forwarded progress from the page's codec engine during a processImage
    // request (e.g. an iterative JPEG-quality attempt) — same status-detail
    // display the old direct codec webview's progress events used.
    case "processImageProgress":
      setStatusDetail(data.message);
      break;
  }
}

// ── DOCUMENT INFO ─────────────────────────────────────────────────
// Builds the document summary (name/page count/unit) sent to the page.
// When rangeSettings (pageRange/pageRangeText) is given, also resolves and
// includes per-page geometry in points for exactly those pages — lets the
// page compute its own oversample/processing plan (see resolvePageProcessingPlan)
// instead of the plugin deciding it unilaterally. Falls back to placeholder
// values if no document is open/accessible.
function getDocumentInfoPayload(rangeSettings) {
  try {
    const doc = app.activeDocument;
    const payload = {
      name: doc.name.replace(/\.[^.]+$/, ""),
      pageCount: doc.pages.length,
      unit: resolveDocUnit(doc)
    };
    if (rangeSettings && (rangeSettings.pageRange || rangeSettings.pageRangeText)) {
      const unit = payload.unit;
      payload.pages = getPageIndices(doc, rangeSettings).map((idx) => {
        const pg = getPage(doc, idx);
        const b = pg.bounds;
        const hPt = toPoints(b[2] - b[0], unit);
        const wPt = toPoints(b[3] - b[1], unit);
        return { index: idx, widthPt: wPt, heightPt: hPt };
      });
    }
    return payload;
  } catch (e) {
    return { name: "DocumentName", pageCount: 0, unit: "px" };
  }
}

// Maps InDesign's measurement-unit enum to the short unit string the UI uses.
function resolveDocUnit(doc) {
  const mu = doc.viewPreferences.horizontalMeasurementUnits.toString();
  if (mu === "MILLIMETERS") return "mm";
  if (mu === "INCHES" || mu === "INCHES_DECIMAL") return "in";
  return "px";
}

// ── FOLDER BROWSE ─────────────────────────────────────────────────
// Handles the page's folder-picker request, remembering the chosen folder
// as the export destination for subsequent runExport calls.
async function handleBrowseFolder() {
  try {
    const folder = await getFS().getFolder();
    if (folder) {
      outputFolderEntry = folder;
      supportLog.info("output_folder_selected", { path: folder.nativePath });
      postToPage("folderSelected", { path: folder.nativePath });
    } else {
      supportLog.info("output_folder_selection_cancelled", {});
      postToPage("folderSelected", { cancelled: true });
    }
  } catch (e) {
    supportLog.error("output_folder_selection_failed", { message: e.message, stack: e.stack || "" });
    postToPage("folderSelected", { cancelled: true });
  }
}

// ── EXPORT / CANCEL ───────────────────────────────────────────────
// Handles a cancel request from the page: flips the exporting flag so the
// export loop stops at its next check, and tells the page to cancel any
// in-flight processing request too (it relays this to its own codec engine).
function handleCancelExport() {
  if (!isExporting) return;
  supportLog.warn("export_cancel_requested", { requestId: currentRequestId || null });
  isExporting = false;
  if (currentRequestId) postToPage("cancelProcessing", { requestId: currentRequestId });
  setStatusBase("Cancelling export...");
}

// Validates preconditions (output folder, codec readiness) before starting
// an export, then delegates to doExport. The webview-not-ready case writes
// a support log immediately since it's otherwise a hard-to-reproduce
// failure to diagnose from a bug report.
async function handleRunExport(settings) {
  if (!outputFolderEntry) {
    postToPage("exportResult", { statusType: "error", message: "No output folder selected.", tooltip: "" });
    return;
  }
  if (settings.format !== "indd" && !codecReady) {
    supportLog.error("export_blocked_webview_not_ready", getExportSettingsSnapshot(settings));
    postToPage("exportResult", { statusType: "error", message: "WebView bridge not ready.", tooltip: "" });
    await writeSupportLogFile("webview_not_ready");
    return;
  }

  await doExport(settings);
}

// Reads the version string rendered in the panel header, for inclusion in
// log/status output (there's no other runtime source of the plugin version
// available to this module).
function getPanelVersion() {
  const el = document.querySelector(".header-version");
  return el ? el.textContent.trim() : "";
}

// Builds a support-log-safe snapshot of the export settings — deliberately
// omits the actual custom prefix/suffix text (only records whether one is
// set) to avoid logging user-entered content.
function getExportSettingsSnapshot(settings) {
  return {
    version: getPanelVersion(),
    format: settings.format,
    dpi: settings.dpi,
    pageRange: settings.pageRange,
    pageRangeText: settings.pageRangeText || "",
    quality: settings.quality,
    maxKB: settings.maxKB,
    smartOversample: settings.smartOversample,
    includeSize: settings.includeSize,
    includePageNum: settings.includePageNum,
    includePrefix: settings.includePrefix,
    hasCustomPrefix: !!settings.customPrefix,
    includeSuffix: settings.includeSuffix,
    hasCustomSuffix: !!settings.customSuffix,
    outputPath: outputFolderEntry ? outputFolderEntry.nativePath : ""
  };
}

// ── HELPERS ───────────────────────────────────────────────────────
// Strips characters that are illegal in file names on Windows/macOS.
function sanitize(s) { return s.replace(/[\/\\:*?"<>|]/g, "_"); }

// Joins a folder path and file name using whichever separator the folder
// path already uses, so the result matches the platform of the input path.
function joinNativePath(folderPath, fileName) {
  const separator = folderPath.includes("\\") ? "\\" : "/";
  return folderPath.replace(/[\\\/]+$/, "") + separator + fileName;
}

function nativePathToFileUrl(path) {
  // Some platforms/entries (observed on macOS with security-scoped folders)
  // report `nativePath` as an already percent-encoded file:// URL rather
  // than a raw OS path. Re-encoding that would double-encode it (%25..).
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(path)) {
    return path;
  }

  const normalized = path.replace(/\\/g, "/");
  const encoded = normalized
    .split("/")
    .map((segment) => (/^[A-Za-z]:$/.test(segment) ? segment : encodeURIComponent(segment)))
    .join("/");

  if (/^[A-Za-z]:\//.test(normalized)) {
    return "file:///" + encoded;
  }

  if (normalized.startsWith("//")) {
    return "file:" + encoded;
  }

  if (normalized.startsWith("/")) {
    return "file://" + encoded;
  }

  return "file:///" + encoded;
}

// Normalizes a native path (separators, trailing slash, case) so two paths
// referring to the same location compare equal regardless of platform quirks.
function normalizeNativePathForCompare(path) {
  return String(path || "")
    .replace(/\\/g, "/")
    .replace(/\/+$/, "")
    .toLowerCase();
}

// Compares two native paths for equality after normalization.
function nativePathsMatch(left, right) {
  const normalizedLeft = normalizeNativePathForCompare(left);
  const normalizedRight = normalizeNativePathForCompare(right);
  return !!normalizedLeft && !!normalizedRight && normalizedLeft === normalizedRight;
}

// Best-effort, string-only heuristic — UXP exposes no OS-level "is this
// drive local or remote" API. Catches confirmed-remote mounts (macOS
// /Volumes/*, Windows UNC \\server\share); cloud-sync folders that keep a
// normal-looking local path (e.g. macOS iCloud Desktop & Documents) aren't
// detectable this way and are only caught by the folder-name substring
// check below, which is a much weaker signal.
function looksLikeNetworkOrCloudPath(nativePath) {
  const path = String(nativePath || "");
  if (/^\/Volumes\//i.test(path)) return "macNetworkVolume";
  if (/^\\\\/.test(path)) return "windowsUncShare";
  if (/onedrive|dropbox|icloud|google drive/i.test(path)) return "possibleCloudSyncFolder";
  return null;
}

// Promise-based sleep, used throughout for polling/backoff waits.
function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Resolves a UXP file entry from a raw native OS path via the file:// URL API.
async function getFileEntryByNativePath(path) {
  return await getFS().getEntryWithUrl(nativePathToFileUrl(path));
}

// Attempts a single binary read of a file, returning both the data and its
// byte length so callers can validate size without a second read.
async function tryReadBinaryFile(file, storage) {
  const binary = await file.read({ format: storage.formats.binary });
  const bytes = binary && (binary.byteLength || binary.length || 0);
  return { binary, bytes };
}

// Re-reads a file one or more times to confirm its size didn't change out
// from under us after the first successful read (see readExportedBinaryFile
// for why this matters on network/cloud paths).
async function verifyStableBinaryRead(file, storage, expectedBytes, context, isFlagged) {
  // A network/cloud-synced path can produce a stale cached read that matches
  // the expected size once and still be wrong (the customer-reported failure
  // mode this is hardening against) — one recheck isn't enough patience
  // there, so flagged paths get two independent confirmations with a longer
  // gap between them instead of one quick recheck.
  const confirmations = isFlagged ? 2 : 1;
  const gapMs = isFlagged ? 200 : 100;
  let confirmedBinary = null;

  for (let i = 0; i < confirmations; i++) {
    await delay(gapMs);
    const reread = await tryReadBinaryFile(file, storage);
    if (reread.bytes !== expectedBytes) {
      throw new Error(`Temporary file size changed after read (${expectedBytes} -> ${reread.bytes})`);
    }
    confirmedBinary = reread.binary;
  }

  supportLog.info("temp_file_read_stable", {
    label: context.label,
    fileName: context.fileName,
    source: context.source,
    folderPath: context.folderPath,
    nativePath: context.nativePath,
    bytes: expectedBytes,
    confirmations
  });
  return confirmedBinary;
}

// Reads a just-exported temp file back into memory, retrying across several
// file-resolution strategies (preferred handle, folder entry, native path,
// folder scan) plus a size-stability recheck — the resilience layer for the
// "InDesign wrote it, UXP can't read it back yet" timing issue seen on
// flaky/mac/network volumes.
async function readExportedBinaryFile(options) {
  const folder = options.folder;
  const fileName = options.fileName;
  const label = options.label;
  const nativePath = options.nativePath || "";
  const preferredFile = options.preferredFile || null;
  const storage = getStorage();
  let lastError = null;
  const lastErrorsBySource = {};

  const fileBaseName = fileName.replace(/\.[^.]+$/, "");

  // Network shares and cloud-sync folders (the confirmed real-world cause of
  // customer read failures) can have write-behind latency well beyond what
  // local disk needs — give them a bigger retry budget instead of the
  // uniform one, rather than giving up at the same point local disk would.
  const isFlagged = !!looksLikeNetworkOrCloudPath(nativePath || folder.nativePath);
  const maxAttempts = isFlagged ? 35 : 25;
  const backoffCapMs = isFlagged ? 800 : 400;

  for (let attempt = 1; attempt <= maxAttempts; attempt++) {
    if (!isExporting) {
      throw new ExportCancelledError();
    }

    const candidates = [];
    if (preferredFile) candidates.push({ source: "preferredFile", getFile: async () => preferredFile });
    candidates.push({ source: "folderEntry", getFile: async () => await folder.getEntry(fileName) });
    if (nativePath) {
      candidates.push({ source: "nativePathFileUrl", getFile: async () => await getFileEntryByNativePath(nativePath) });
    }
    candidates.push({ source: "folderScan", getFile: async () => {
      const entries = await folder.getEntries();
      const match = entries.find(e => e.isFile && e.name.startsWith(fileBaseName));
      if (!match) throw new Error(`No file starting with '${fileBaseName}' found in temp folder`);
      return match;
    }});

    for (const candidate of candidates) {
      try {
        const file = await candidate.getFile();
        const result = await tryReadBinaryFile(file, storage);
        if (result.bytes > 0) {
          const stableBinary = await verifyStableBinaryRead(file, storage, result.bytes, {
            label,
            fileName,
            source: candidate.source,
            folderPath: folder.nativePath || "",
            nativePath
          }, isFlagged);
          if (attempt > 1 || candidate.source !== "preferredFile") {
            supportLog.info("temp_file_read_retry_succeeded", {
              label,
              fileName,
              attempt,
              source: candidate.source,
              folderPath: folder.nativePath || "",
              nativePath,
              bytes: result.bytes
            });
          }
          return { file, binary: stableBinary };
        }

        lastError = new Error("Temporary export file is empty");
        lastErrorsBySource[candidate.source] = { message: lastError.message, code: null };
      } catch (err) {
        lastError = err;
        // err.code (e.g. EBUSY/EACCES/EPERM/ENOENT on some platforms) is the
        // one signal that can tell a transient AV/cloud-sync lock apart from
        // a genuine permission problem — capture it alongside the message
        // wherever a temp-file read/probe fails, purely for diagnosing the
        // mac/Windows "written but not readable" cases from support logs.
        lastErrorsBySource[candidate.source] = { message: err.message, code: err.code || null };
        if (attempt === 1) {
          supportLog.warn("temp_file_read_candidate_failed", {
            label,
            fileName,
            source: candidate.source,
            folderPath: folder.nativePath || "",
            nativePath,
            message: err.message,
            code: err.code || null
          });
        }
      }
    }

    await delay(Math.min(100 + attempt * 25, backoffCapMs));
  }

  supportLog.error("temp_file_read_failed", {
    label,
    fileName,
    folderPath: folder.nativePath || "",
    nativePath,
    possibleNetworkOrCloudPath: isFlagged,
    attemptsMade: maxAttempts,
    lastErrorsBySource
  });
  const networkHint = isFlagged ? " — this location looks like a network or cloud-synced path, which is a known source of read reliability issues" : "";
  throw new Error(`${label} could not be read (${fileName})${networkHint}: ${lastError ? lastError.message : "unknown error"}`);
}

// Startup sanity check for a candidate temp folder: writes a tiny
// known-content file and reads it straight back, to confirm write+read
// actually round-trips there before real page exports rely on it.
async function probeProcessingTempFolder(folder, location) {
  const storage = getStorage();
  const probeName = `probe_${Date.now()}.bin`;
  let probeFile = null;

  try {
    probeFile = await folder.createFile(probeName, { overwrite: true });
    const probeBytes = new Uint8Array([70, 85, 71, 65]);
    await probeFile.write(probeBytes, { format: storage.formats.binary });

    const result = await tryReadBinaryFile(probeFile, storage);
    if (result.bytes !== probeBytes.length) {
      throw new Error(`Probe read returned ${result.bytes} byte(s), expected ${probeBytes.length}`);
    }

    supportLog.info("processing_temp_folder_probe_succeeded", {
      location,
      path: folder.nativePath || "",
      probeFile: probeName
    });
  } catch (err) {
    supportLog.warn("processing_temp_folder_probe_failed", {
      location,
      path: folder && folder.nativePath ? folder.nativePath : "",
      message: err.message,
      code: err.code || null
    });
    throw err;
  } finally {
    if (probeFile) {
      try { await probeFile.delete(); } catch (err) { }
    }
  }
}

// Creates a throwaway 1-page document and exports a tiny JPEG from it,
// used purely to verify InDesign's own exportFile() can actually write to
// a candidate temp location (a plain file-write probe wouldn't catch
// InDesign-specific export issues).
async function exportProbeImageToTmpFile(tmpPath) {
  const newDoc = app.documents.add(false);
  try {
    newDoc.documentPreferences.pageWidth = 12;
    newDoc.documentPreferences.pageHeight = 12;

    const pageLabel = newDoc.pages.item(0).name;
    const jp = app.jpegExportPreferences;
    jp.exportResolution = 72;
    jp.jpegQuality = JPEGOptionsQuality.LOW;
    jp.antiAlias = true;
    jp.jpegExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
    jp.pageString = pageLabel;
    newDoc.exportFile(ExportFormat.JPG, tmpPath, false);
  } finally {
    try { newDoc.close(SaveOptions.NO); } catch (e) { }
  }
}

// Runs exportProbeImageToTmpFile against a candidate folder and reads the
// result back through the full readExportedBinaryFile retry path, so this
// probe exercises the same export+readback flow real pages will use.
async function probeInDesignTempExport(folder, location) {
  const probeName = "probe.jpg";
  const fallbackPath = joinNativePath(folder.nativePath || "", probeName);
  let probeFile = null;
  let probePath = fallbackPath;

  try {
    probeFile = await folder.createFile(probeName, { overwrite: true });
    probePath = probeFile.nativePath || fallbackPath;
    supportLog.info("processing_temp_folder_indesign_probe_started", {
      location,
      folderPath: folder.nativePath || "",
      fileName: probeName,
      path: probePath
    });

    await exportProbeImageToTmpFile(probePath);
    const result = await readExportedBinaryFile({
      folder,
      fileName: probeName,
      label: `${location} InDesign temp export probe`,
      nativePath: probePath,
      preferredFile: probeFile
    });
    probeFile = result.file;
    supportLog.info("processing_temp_folder_indesign_probe_succeeded", {
      location,
      folderPath: folder.nativePath || "",
      fileName: probeName,
      path: probePath,
      bytes: result.binary.byteLength || result.binary.length || null
    });
  } catch (err) {
    supportLog.warn("processing_temp_folder_indesign_probe_failed", {
      location,
      folderPath: folder && folder.nativePath ? folder.nativePath : "",
      fileName: probeName,
      path: probePath,
      message: err.message,
      code: err.code || null
    });
    throw err;
  } finally {
    if (probeFile) {
      try { await deleteFileAtPath(folder, probeName, probeFile); } catch (err) { }
    }
  }
}

// Creates (or reuses) a per-session temp subfolder under parentFolder and
// runs both probes against it before handing it back as usable for
// processed exports; deletes the folder again if probing throws.
async function createAndProbeProcessingTempFolder(parentFolder, location) {
  supportLog.info("processing_temp_folder_candidate_started", {
    location,
    parentPath: parentFolder.nativePath || ""
  });

  let rootFolder = null;

  try {
    rootFolder = await parentFolder.getEntry("FugaImageExport_Temp");
  } catch (e) {
    rootFolder = await parentFolder.createFolder("FugaImageExport_Temp");
  }

  const folder = await rootFolder.createFolder(`session_${Date.now()}`, { overwrite: true });

  try {
    await probeProcessingTempFolder(folder, location);

    try {
      await probeInDesignTempExport(folder, location);
    } catch (err) {
      // Non-fatal on purpose: this probe already retried through the full
      // readExportedBinaryFile() budget, so a failure here is a real signal
      // the location is shaky — but rejecting the candidate outright can
      // turn a shaky-but-usually-fine location into an upfront export
      // failure. Prefer accepting it and letting the per-page retry/reselect
      // logic keep trying rather than blocking before a single page ran.
      supportLog.warn("processing_temp_folder_indesign_probe_non_fatal", {
        location,
        path: folder.nativePath || "",
        message: err.message
      });
    }

    supportLog.info("processing_temp_folder_created", {
      location,
      parentPath: parentFolder.nativePath || "",
      path: folder.nativePath || "",
      possibleNetworkOrCloudPath: looksLikeNetworkOrCloudPath(folder.nativePath)
    });

    return { folder, rootFolder, location, path: folder.nativePath || "" };
  } catch (err) {
    try { await folder.delete(); } catch (deleteErr) { }
    throw err;
  }
}

// Picks and prepares a temp folder for processed-export intermediate files,
// trying candidate locations in priority order and skipping any previously
// excluded as unreliable this session.
async function getProcessingTempFolder(fs, outputFolder, excludedLocations) {
  // Prefer locations outside the user's chosen output folder: it is often a
  // cloud-synced path (iCloud Desktop, OneDrive, Dropbox, Google Drive), and
  // those sync daemons intermittently evict/relock files right after they're
  // written, which a one-time startup probe won't catch under real export
  // load. Keep outputFolder only as a last-resort fallback.
  let attempts = [
    { location: "temporaryFolder", getParent: async () => await fs.getTemporaryFolder() },
    { location: "dataFolder", getParent: async () => await fs.getDataFolder() }
  ];

  if (outputFolder) {
    attempts.push({
      location: "outputFolder",
      getParent: async () => outputFolder
    });
  }

  if (excludedLocations && excludedLocations.size) {
    const remaining = attempts.filter(attempt => !excludedLocations.has(attempt.location));
    // If exclusions would wipe out every candidate, ignore them rather than
    // fail outright — a previously-flaky location is still better than none.
    if (remaining.length) attempts = remaining;
  }

  const errors = [];

  for (const attempt of attempts) {
    try {
      const parentFolder = await attempt.getParent();
      return await createAndProbeProcessingTempFolder(parentFolder, attempt.location);
    } catch (err) {
      errors.push(`${attempt.location}: ${err.message}`);
      supportLog.warn("processing_temp_folder_candidate_failed", {
        location: attempt.location,
        message: err.message,
        code: err.code || null
      });
    }
  }

  throw new Error(`Could not create a readable temporary processing folder. ${errors.join("; ")}`);
}

// Deletes a temp file by its already-open entry, falling back to
// re-resolving it by name if that handle has gone stale.
async function deleteFileAtPath(folder, fileName, fileEntry) {
  if (fileEntry) {
    try {
      await fileEntry.delete();
      return;
    } catch (err) {
      // InDesign may replace the file after UXP first resolves it; retry by path.
    }
  }

  const freshEntry = await folder.getEntry(fileName);
  await freshEntry.delete();
}

// Converts a raw document-unit measurement to points (InDesign's native
// unit); px and unrecognized units pass through unchanged.
function toPoints(val, unit) {
  if (unit === "mm") return val / 0.352778;
  if (unit === "in") return val * 72;
  return val;
}

// Converts a point value to the requested display unit for filenames/UI —
// px is derived using the given dpi, in/mm are rounded to sensible display
// precision.
function ptToUnit(pt, unit, dpi) {
  if (unit === "px") return Math.round(pt * (dpi / 72));
  if (unit === "in") return Math.round(pt * 100) / 100;
  if (unit === "mm") return Math.round(pt * 10) / 10;
  return pt;
}

// For INDD exports — no DPI/pixel concept for a native save, so size is
// shown in the document's own measurement unit, unconverted (whatever
// wRaw/hRaw already are at the call site — not necessarily mm).
function buildFilenameIndd(settings, docName, wRaw, hRaw, pageLabel) {
  const values = {
    prefix: (settings.includePrefix && settings.customPrefix) ? sanitize(settings.customPrefix) : "",
    doc: sanitize(docName),
    size: settings.includeSize ? `${wRaw}x${hRaw}` : "",
    page: settings.includePageNum ? `p${sanitize(pageLabel)}` : "",
    suffix: (settings.includeSuffix && settings.customSuffix) ? sanitize(settings.customSuffix) : ""
  };
  return applyFilenameTemplate(resolveFilenameTemplate(settings), values);
}

// For image exports — size is shown in the user's chosen display unit.
function buildFilename(settings, docName, unit, wPt, hPt, pageLabel) {
  const values = {
    prefix: (settings.includePrefix && settings.customPrefix) ? sanitize(settings.customPrefix) : "",
    doc: sanitize(docName),
    size: settings.includeSize ? `${ptToUnit(wPt, unit, 72)}x${ptToUnit(hPt, unit, 72)}` : "",
    page: settings.includePageNum ? `p${sanitize(pageLabel)}` : "",
    suffix: (settings.includeSuffix && settings.customSuffix) ? sanitize(settings.customSuffix) : ""
  };
  return applyFilenameTemplate(resolveFilenameTemplate(settings), values);
}

// Parses the page-range settings into zero-based page indices. Supports
// "all" plus a comma-separated list of single pages and ranges (e.g.
// "1,3-5"); out-of-bounds or malformed parts are silently dropped rather
// than erroring, to stay lenient with hand-typed input.
function getPageIndices(doc, settings) {
  const total = doc.pages.length;
  if (settings.pageRange === "all") return Array.from({ length: total }, (_, i) => i);
  const indices = [];
  const parts = String(settings.pageRangeText || "").split(",");
  for (const part of parts) {
    const p = part.trim();
    if (p.includes("-")) {
      const [s, e] = p.split("-").map(n => parseInt(n) - 1);
      for (let i = s; i <= e && i < total; i++) if (i >= 0) indices.push(i);
    } else {
      const i = parseInt(p) - 1;
      if (i >= 0 && i < total) indices.push(i);
    }
  }
  return indices;
}

// Returns the page object at a given zero-based index.
function getPage(doc, idx) { return doc.pages.item(idx); }

// Determines how many times over the target resolution to render a page
// before downsampling: smaller pages need more oversampling to look sharp
// at the same DPI, so smaller short-side-px thresholds map to bigger
// multipliers. Returns 1x (no oversampling) if the feature is off or no
// threshold matches.
function getOversampleMult(settings, wPt, hPt) {
  if (!settings.smartOversample) return 1;
  const shortPx = Math.round(Math.min(wPt, hPt) * (settings.dpi / 72));
  const thresholds = resolveOversampleThresholds(settings);
  for (const t of thresholds) {
    if (shortPx < t.maxShortPx) return t.mult;
  }
  return 1;
}

// Computes the export/oversample plan for a page: the resolution to render
// at (exportDpi/sourceWidth/sourceHeight) and the resolution to downsample
// to (targetWidth/targetHeight). Degrades gracefully — first the oversample
// multiplier, then as a last resort the DPI itself — to keep the rendered
// source under HARD_MAX_PROCESSING_SOURCE_MP, which is what the WASM codec
// can safely decode.
function getProcessingExportPlan(settings, wPt, hPt) {
  const maxSourceMp = resolveMaxSourceMp(settings);
  const mult = getOversampleMult(settings, wPt, hPt);
  const baseWidth = Math.round(wPt * (settings.dpi / 72));
  const baseHeight = Math.round(hPt * (settings.dpi / 72));
  const baseMp = (baseWidth * baseHeight) / 1000000;
  const sourceMp = (baseWidth * mult * baseHeight * mult) / 1000000;

  // Common case: the requested oversample multiplier already fits under the cap.
  if (sourceMp <= maxSourceMp) {
    return {
      exportDpi: settings.dpi * mult,
      targetWidth: baseWidth,
      targetHeight: baseHeight,
      sourceWidth: baseWidth * mult,
      sourceHeight: baseHeight * mult,
      sourceMp,
      oversampleMultiplier: mult
    };
  }

  // The un-oversampled export already fits under the cap, but the full
  // requested multiplier wouldn't — reduce the multiplier just enough to
  // fit rather than dropping oversampling entirely.
  if (baseMp <= maxSourceMp) {
    // Largest integer multiplier whose resulting megapixels stay at/under the cap.
    const safeMult = Math.max(1, Math.floor(Math.sqrt((maxSourceMp * 1000000) / (baseWidth * baseHeight))));
    supportLog.warn("oversample_limited_by_source_size", {
      requestedMultiplier: mult,
      appliedMultiplier: safeMult,
      requestedDpi: settings.dpi,
      exportDpi: settings.dpi * safeMult,
      targetWidth: baseWidth,
      targetHeight: baseHeight,
      sourceMp,
      maxSourceMp
    });
    return {
      exportDpi: settings.dpi * safeMult,
      targetWidth: baseWidth,
      targetHeight: baseHeight,
      sourceWidth: baseWidth * safeMult,
      sourceHeight: baseHeight * safeMult,
      sourceMp: (baseWidth * safeMult * baseHeight * safeMult) / 1000000,
      oversampleMultiplier: safeMult
    };
  }

  // Even without oversampling the page is too large for the cap — the only
  // way left to fit is to reduce the export DPI itself (and therefore the
  // final output resolution too).
  const scale = Math.sqrt((maxSourceMp * 1000000) / (baseWidth * baseHeight));
  const exportDpi = Math.max(1, Math.floor(settings.dpi * scale));
  const targetWidth = Math.max(1, Math.round(wPt * (exportDpi / 72)));
  const targetHeight = Math.max(1, Math.round(hPt * (exportDpi / 72)));

  supportLog.warn("oversample_limited_by_source_size", {
    requestedMultiplier: mult,
    appliedMultiplier: 1,
    requestedDpi: settings.dpi,
    exportDpi,
    targetWidth,
    targetHeight,
    sourceMp: baseMp,
    maxSourceMp
  });
  return {
    exportDpi,
    targetWidth,
    targetHeight,
    sourceWidth: targetWidth,
    sourceHeight: targetHeight,
    sourceMp: (targetWidth * targetHeight) / 1000000,
    oversampleMultiplier: 1
  };
}

// Validates a page-supplied per-page plan (from settings.pagePlans) before
// trusting it: every dimension must be a finite positive number, and the
// claimed sourceMp is recomputed from the claimed dimensions rather than
// trusted as sent, then checked against the same ceiling
// getProcessingExportPlan itself enforces — a bad/stale web-sent plan can
// never push processing past what the plugin allows.
function isValidPagePlan(plan, settings) {
  if (!plan) return false;
  const nums = [plan.exportDpi, plan.targetWidth, plan.targetHeight, plan.sourceWidth, plan.sourceHeight, plan.oversampleMultiplier];
  if (!nums.every(n => Number.isFinite(n) && n > 0)) return false;
  if (typeof plan.needsProcessing !== "boolean") return false;
  const sourceMp = (plan.sourceWidth * plan.sourceHeight) / 1000000;
  return sourceMp <= resolveMaxSourceMp(settings);
}

// Prefers the page's own processing plan for this page (computed web-side
// from geometry the plugin sent via documentInfo — see "Web-tunable
// processing config" in docs/migration/MIGRATION_PLAN.md) over the plugin
// computing it itself, falling back to getProcessingExportPlan whenever the
// page didn't send one, sent one for a different page, or sent something
// that fails validation.
function resolvePageProcessingPlan(settings, pgIdx, wPt, hPt) {
  const sent = settings.pagePlans && settings.pagePlans[pgIdx];
  if (isValidPagePlan(sent, settings)) return sent;

  const plan = getProcessingExportPlan(settings, wPt, hPt);
  const effectiveMaxKB = getEffectiveMaxKB(settings);
  plan.needsProcessing = settings.format === "webp" || effectiveMaxKB > 0 || plan.oversampleMultiplier > 1;
  return plan;
}

// Maps the UI's named quality tier to InDesign's JPEGOptionsQuality enum.
function getJpegQuality(q) {
  const map = { "low": JPEGOptionsQuality.LOW, "medium": JPEGOptionsQuality.MEDIUM, "high": JPEGOptionsQuality.HIGH, "maximum": JPEGOptionsQuality.MAXIMUM };
  return map[q] || JPEGOptionsQuality.HIGH;
}

// A maxKB size cap only makes sense for the formats the page says support
// it (see resolveMaxSizeSupportedFormats) — anything else has no comparable
// size dial, so treat their cap as unset (0) regardless of what was sent.
function getEffectiveMaxKB(settings) {
  return resolveMaxSizeSupportedFormats(settings).includes(settings.format) ? settings.maxKB : 0;
}

// Buckets a processed-export failure into a coarse category (temp-file
// read, InDesign export, or generic processing) by matching known
// error-message substrings. Returns the raw category + message rather than
// composed display text — doExport still needs the category itself to
// detect a run of temp-file trouble worth switching locations over; the
// page (exportPanelMain.js) owns turning this into user-facing wording, so
// that copy can change without a plugin update.
function classifyProcessedExportError(err) {
  const message = err && err.message ? err.message : "unknown error";
  if (/could not be read|Temporary export file|Temporary file size changed/i.test(message)) {
    return { category: "temp_read", message };
  }
  if (/exportFile|export/i.test(message)) {
    return { category: "temp_export", message };
  }
  return { category: "processing", message };
}

// ── STATUS TEXT (built here, pushed to the page as plain strings) ──
// Sets the primary status line, clearing any stale detail left over from a
// previous step, and pushes the result to the page.
function setStatusBase(msg) {
  exportStatusBase = msg || "";
  exportStatusDetail = "";
  postProgress();
}

// Combines the base and detail status strings into the single line shown/
// sent to the page.
function composeStatusMessage() {
  if (exportStatusBase && exportStatusDetail) {
    return `${exportStatusBase} ${exportStatusDetail}`;
  }
  return exportStatusBase || exportStatusDetail;
}

let lastProgressPercent = 0;
// Pushes the current progress percent (or the last known one, if omitted)
// and status message to the page.
function postProgress(percent) {
  if (typeof percent === "number") lastProgressPercent = percent;
  postToPage("exportProgress", { percent: lastProgressPercent, message: composeStatusMessage() });
}

// ── DIAGNOSTICS ───────────────────────────────────────────────────
// Captures host/runtime environment details (app version, UXP domains, user
// agent, etc.) for support logs. fs.supportedDomains access is wrapped
// separately since it can itself throw on some hosts.
function getRuntimeSnapshot(fs) {
  let supportedDomains = [];
  try {
    if (fs && fs.supportedDomains && typeof fs.supportedDomains.map === "function") {
      supportedDomains = fs.supportedDomains.map(domain => String(domain));
    }
  } catch (err) {
    supportedDomains = [`error: ${err.message}`];
  }

  return {
    appName: app && app.name ? app.name : "",
    appVersion: app && app.version ? app.version : "",
    panelVersion: getPanelVersion(),
    manifestVersion: 5,
    localFileSystemPermission: "fullAccess",
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "",
    platform: typeof navigator !== "undefined" ? navigator.platform || "" : "",
    language: typeof navigator !== "undefined" ? navigator.language || "" : "",
    supportedDomains
  };
}

// Captures a lightweight snapshot of the active document's state for
// support logs; tolerates any property-access failure rather than aborting
// the export just because logging failed.
function getDocumentSnapshot(doc) {
  try {
    return {
      name: doc.name || "",
      pages: doc.pages ? doc.pages.length : null,
      horizontalMeasurementUnits: doc.viewPreferences && doc.viewPreferences.horizontalMeasurementUnits
        ? doc.viewPreferences.horizontalMeasurementUnits.toString()
        : ""
    };
  } catch (err) {
    return { error: err.message };
  }
}

// Flushes the in-memory support log buffer to a file in the plugin's data
// folder. Failures here are logged but swallowed — this is itself a
// diagnostics path and must never be allowed to break the export it's
// trying to explain.
async function writeSupportLogFile(reason) {
  try {
    supportLog.info("support_log_write_started", { reason });
    const fs = getStorage().localFileSystem;
    const dataFolder = await fs.getDataFolder();
    const file = await dataFolder.createFile("fuga_image_export.log", { overwrite: true });
    await file.write(supportLog.getText());
    supportLog.info("support_log_write_finished", {
      filename: "fuga_image_export.log",
      location: "dataFolder",
      path: file.nativePath || ""
    });
  } catch (err) {
    supportLog.error("support_log_write_failed", { message: err.message, stack: err.stack || "" });
  }
}

// Resolves the on-disk path of the support log file for display in the UI,
// with a human-readable fallback if the data folder can't be resolved.
async function resolveSupportLogPath() {
  try {
    const dataFolder = await getStorage().localFileSystem.getDataFolder();
    const basePath = dataFolder.nativePath || "";
    if (basePath) return `${basePath}\\fuga_image_export.log`;
    return "UXP plugin data folder: fuga_image_export.log";
  } catch (err) {
    supportLog.error("support_log_path_resolve_failed", { message: err.message, stack: err.stack || "" });
    return "Could not resolve plugin data folder path. The file is named fuga_image_export.log.";
  }
}

// ── DO EXPORT ─────────────────────────────────────────────────────
// The central export orchestrator invoked by handleRunExport: resolves the
// requested page list, exports each page either directly via InDesign or
// through the WASM-codec webview when processing is needed, tracks
// failures/warnings/temp-folder health per page, and reports a final status
// to the page once done (or on cancel/error).
async function doExport(settings) {
  let warnings = [];
  let failures = [];
  let exportError = null;
  let supportLogReason = "export_finished";
  let processingTempFolder = null;
  let processingTempRootFolder = null;
  let processingTempLocation = "";
  let consecutiveTempFailures = 0;
  let forceTempFolderReselect = false;
  const excludedTempLocations = new Set();

  isExporting = true;
  exportStatusBase = "";
  exportStatusDetail = "";
  lastProgressPercent = 0;
  setStatusBase("Exporting...");
  supportLog.info("export_started", getExportSettingsSnapshot(settings), { pinned: true });

  try {
    const fs = getFS();
    const doc = app.activeDocument;
    supportLog.info("runtime_snapshot", getRuntimeSnapshot(fs), { pinned: true });
    supportLog.info("document_snapshot", getDocumentSnapshot(doc), { pinned: true });
    const unit = resolveDocUnit(doc);
    const docName = doc.name.replace(/\.[^.]+$/, "");
    const indices = getPageIndices(doc, settings);
    const nameCounts = {};
    const outPath = outputFolderEntry.nativePath;
    const outputFolder = outputFolderEntry;
    let completedCount = 0;

    supportLog.info("export_pages_resolved", {
      requestedRange: settings.pageRange,
      pageRangeText: settings.pageRangeText || "",
      count: indices.length,
      indices: indices.map(index => index + 1)
    });

    for (let i = 0; i < indices.length; i++) {
      if (!isExporting) {
        supportLog.warn("export_loop_stopped", { completedCount, requestedCount: indices.length });
        supportLogReason = "export_cancelled";
        break;
      }

      const pgIdx = indices[i];
      const pg = getPage(doc, pgIdx);
      const b = pg.bounds;
      const hRaw = b[2] - b[0];
      const wRaw = b[3] - b[1];
      const hPt = toPoints(hRaw, unit);
      const wPt = toPoints(wRaw, unit);
      const processingPlan = resolvePageProcessingPlan(settings, pgIdx, wPt, hPt);
      const mult = processingPlan.oversampleMultiplier;
      const exportDpi = processingPlan.exportDpi;
      const pageLabel = pg.name;

      const targetWidth = processingPlan.targetWidth;
      const targetHeight = processingPlan.targetHeight;

      let baseName = buildFilename(settings, docName, unit, wRaw, hRaw, pageLabel);
      if (nameCounts[baseName] !== undefined) { nameCounts[baseName]++; baseName += "_" + nameCounts[baseName]; }
      else { nameCounts[baseName] = 0; }

      postProgress(Math.round((i / indices.length) * 90));
      setStatusBase(`Exporting page ${pageLabel} of ${indices.length}...`);

      const fmt = settings.format;
      const destPath = `${outPath}/${baseName}.${fmt === "jpg" ? "jpg" : fmt}`;
      const effectiveMaxKB = getEffectiveMaxKB(settings);
      // Direct InDesign export only covers plain jpg/png at 1x. Anything
      // needing a size cap, WebP conversion, or oversample-then-downsample
      // has to go through the WASM codec webview instead. Preferring the
      // page's own plan (resolvePageProcessingPlan) means this can now be a
      // web-side decision, not just a plugin-computed one.
      const needsProcessing = processingPlan.needsProcessing;

      supportLog.info("page_export_started", {
        pageNumber: pgIdx + 1,
        pageLabel,
        format: fmt,
        route: fmt === "indd" ? "indd" : needsProcessing ? "processed_webview" : "direct",
        baseName,
        widthRaw: wRaw,
        heightRaw: hRaw,
        unit,
        targetWidth,
        targetHeight,
        requestedDpi: settings.dpi,
        exportDpi,
        oversampleMultiplier: mult,
        plannedSourceWidth: processingPlan.sourceWidth,
        plannedSourceHeight: processingPlan.sourceHeight,
        plannedSourceMp: processingPlan.sourceMp,
        maxProcessingSourceMp: resolveMaxSourceMp(settings),
        maxKB: effectiveMaxKB
      });

      // ── INDD EXPORT ──
      if (fmt === "indd") {
        const inddName = buildFilenameIndd(settings, docName, wRaw, hRaw, pageLabel);
        const result = await exportPageAsIndd(doc, pg, outPath, inddName);
        if (!result.ok) {
          const failure = { page: pgIdx + 1, category: "indd_export", message: result.error };
          failures.push(failure);
          supportLog.error("page_export_failed", { pageNumber: pgIdx + 1, failure: `p${failure.page}: ${failure.message}` });
        } else {
          completedCount++;
          supportLog.info("page_export_finished", { pageNumber: pgIdx + 1, format: fmt, file: `${inddName}.indd` });
        }
        continue;
      }

      // "+" prefix makes InDesign treat the number as an absolute page
      // index rather than as a page-name/label lookup.
      const absPageString = `+${pgIdx + 1}`;

      if (fmt === "jpg" && !needsProcessing) {
        const jp = app.jpegExportPreferences;
        jp.exportResolution = settings.dpi;
        jp.antiAlias = true;
        jp.jpegExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
        jp.pageString = absPageString;
        jp.jpegQuality = getJpegQuality(settings.quality);
        doc.exportFile(ExportFormat.JPG, destPath, false);
        completedCount++;
        supportLog.info("page_export_finished", { pageNumber: pgIdx + 1, format: fmt, file: `${baseName}.jpg` });

      } else if (fmt === "png" && !needsProcessing) {
        const pp = app.pngExportPreferences;
        pp.exportResolution = settings.dpi;
        pp.transparentBackground = settings.pngTransparent;
        pp.antiAlias = true;
        pp.pngExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
        pp.pageString = absPageString;
        doc.exportFile(ExportFormat.PNG_FORMAT, destPath, false);
        completedCount++;
        supportLog.info("page_export_finished", { pageNumber: pgIdx + 1, format: fmt, file: `${baseName}.png` });

      } else {
        const isPng = fmt === "png";
        const tmpExt = isPng ? "png" : "jpg";
        // A forced reselect means the current temp location was just
        // excluded after repeated failures (see the isTempFailure handling
        // below) — tear down its session folder before picking a new one.
        if (forceTempFolderReselect && processingTempFolder) {
          await deleteProcessingTempFolder(processingTempFolder, processingTempRootFolder, processingTempLocation);
          processingTempFolder = null;
          processingTempRootFolder = null;
          processingTempLocation = "";
        }
        forceTempFolderReselect = false;
        if (!processingTempFolder) {
          const tempSelection = await getProcessingTempFolder(fs, outputFolder, excludedTempLocations);
          processingTempFolder = tempSelection.folder;
          processingTempRootFolder = tempSelection.rootFolder || null;
          processingTempLocation = tempSelection.location;
          supportLog.info("processing_temp_folder_selected", {
            location: processingTempLocation,
            path: tempSelection.path || processingTempFolder.nativePath || ""
          }, { pinned: true });
        }
        const tmpName = `p${pgIdx + 1}.${tmpExt}`;
        const tmpPath = joinNativePath(processingTempFolder.nativePath, tmpName);
        let tmpFile = null;
        let tmpNativePath = tmpPath;

        try {
          tmpFile = await processingTempFolder.createFile(tmpName, { overwrite: true });
          tmpNativePath = tmpFile.nativePath || tmpPath;
          if (tmpFile.nativePath && tmpPath && !nativePathsMatch(tmpFile.nativePath, tmpPath)) {
            supportLog.warn("page_temp_path_mismatch", {
              pageNumber: pgIdx + 1,
              fileName: tmpName,
              plannedPath: tmpPath,
              fileEntryPath: tmpFile.nativePath
            });
          }
          supportLog.info("page_temp_file_precreated", {
            pageNumber: pgIdx + 1,
            fileName: tmpName,
            location: processingTempLocation,
            folderPath: processingTempFolder.nativePath || "",
            path: tmpNativePath
          });

          supportLog.info("page_temp_export_started", {
            pageNumber: pgIdx + 1,
            tmpExt,
            exportDpi,
            plannedSourceWidth: processingPlan.sourceWidth,
            plannedSourceHeight: processingPlan.sourceHeight,
            plannedSourceMp: processingPlan.sourceMp,
            location: processingTempLocation,
            folderPath: processingTempFolder.nativePath || "",
            path: tmpNativePath
          });
          await exportPageToTmpFile(doc, pgIdx + 1, tmpNativePath, isPng, exportDpi, settings.pngTransparent);
          supportLog.info("page_temp_export_finished", {
            pageNumber: pgIdx + 1,
            tmpExt,
            exportDpi,
            location: processingTempLocation,
            folderPath: processingTempFolder.nativePath || "",
            path: tmpNativePath
          });

          await delay(150); // wait if AV holds the temp file

          const exportedTemp = await readExportedBinaryFile({
            folder: processingTempFolder,
            fileName: tmpName,
            label: `page ${pgIdx + 1} temp export`,
            nativePath: tmpNativePath,
            preferredFile: tmpFile
          });
          tmpFile = exportedTemp.file;
          const binary = exportedTemp.binary;
          const inputBase64 = base64.arrToB64(new Uint8Array(binary));
          supportLog.info("page_processing_started", {
            pageNumber: pgIdx + 1,
            inputBytes: binary.byteLength || binary.length || null,
            format: fmt,
            sourceFormat: isPng ? "png" : "jpg",
            quality: effectiveMaxKB > 0 ? 80 : resolveQualityPercent(settings),
            maxKB: effectiveMaxKB,
            targetWidth,
            targetHeight
          });

          const requestPromise = sendProcessImageRequest({
            format: fmt,
            sourceFormat: isPng ? "png" : "jpg",
            quality: effectiveMaxKB > 0 ? 80 : resolveQualityPercent(settings),
            maxKB: effectiveMaxKB,
            targetWidth,
            targetHeight,
            inputBase64
          });

          currentRequestId = requestPromise.requestId;
          const response = await requestPromise;
          supportLog.info("page_processing_finished", {
            pageNumber: pgIdx + 1,
            requestId: currentRequestId,
            info: response.info || {},
            warning: response.warning || ""
          });

          const outputBytes = base64.b64ToArr(response.outputBase64);
          const ext = fmt === "jpg" ? "jpg" : fmt;
          const file = await outputFolder.createFile(`${baseName}.${ext}`, { overwrite: true });
          await file.write(outputBytes, { format: getStorage().formats.binary });
          completedCount++;
          supportLog.info("page_export_finished", {
            pageNumber: pgIdx + 1,
            format: fmt,
            file: `${baseName}.${ext}`,
            outputBytes: outputBytes.length
          });

          // Back-calculate the DPI the codec actually delivered — it may
          // have downscaled further to satisfy the maxKB cap — so a
          // below-target result can be logged and surfaced as a warning.
          const effectiveDpi = Math.round((response.info.width / (wPt / 72)));
          if (effectiveDpi < settings.dpi) {
            supportLog.warn("page_effective_dpi_reduced", {
              pageNumber: pgIdx + 1,
              requestedDpi: settings.dpi,
              effectiveDpi
            });
          }

          if (response.warning) {
            const warning = { page: pgIdx + 1, message: response.warning };
            warnings.push(warning);
            supportLog.warn("page_export_warning", { pageNumber: pgIdx + 1, warning: `p${warning.page}: ${warning.message}` });
          }
        } catch (err) {
          if (err instanceof ExportCancelledError) {
            supportLog.info("page_processing_cancelled", { pageNumber: pgIdx + 1 });
          } else {
            const classified = classifyProcessedExportError(err);
            const failure = { page: pgIdx + 1, category: classified.category, message: classified.message };
            failures.push(failure);
            supportLog.error("page_processing_failed", {
              pageNumber: pgIdx + 1,
              failure: `p${failure.page}: ${failure.category} - ${failure.message}`,
              message: err.message,
              code: err.code || null,
              stack: err.stack || ""
            });

            // Track consecutive temp-file-related failures (as opposed to
            // codec/processing errors) so a genuinely bad temp location gets
            // abandoned rather than retried page after page.
            const isTempFailure = classified.category === "temp_read" || classified.category === "temp_export";
            if (isTempFailure) {
              consecutiveTempFailures++;
              // Three in a row is treated as proof the location itself is
              // bad (not just one unlucky page) — exclude it and force a
              // fresh folder pick for the next page.
              if (consecutiveTempFailures >= 3 && processingTempLocation) {
                supportLog.warn("processing_temp_folder_switch_triggered", {
                  location: processingTempLocation,
                  path: processingTempFolder ? processingTempFolder.nativePath || "" : "",
                  consecutiveFailures: consecutiveTempFailures
                });
                excludedTempLocations.add(processingTempLocation);
                forceTempFolderReselect = true;
                consecutiveTempFailures = 0;
              }
            } else {
              consecutiveTempFailures = 0;
            }
          }
        } finally {
          currentRequestId = null;
          try {
            await deleteFileAtPath(processingTempFolder, tmpName, tmpFile);
            supportLog.info("page_temp_file_deleted", {
              pageNumber: pgIdx + 1,
              fileName: tmpName,
              location: processingTempLocation,
              folderPath: processingTempFolder.nativePath || "",
              path: tmpNativePath
            });
          } catch (e) {
            supportLog.warn("page_temp_file_delete_failed", {
              pageNumber: pgIdx + 1,
              fileName: tmpName,
              location: processingTempLocation,
              folderPath: processingTempFolder ? processingTempFolder.nativePath || "" : "",
              path: tmpNativePath,
              message: e.message
            });
          }
        }
      }

      // Periodically flush the support log during long exports (not just at
      // the end) so a crash or force-quit mid-export still leaves
      // diagnostics on disk.
      if ((i + 1) % 5 === 0 || i === indices.length - 1) {
        await writeSupportLogFile("export_in_progress");
      }
    }

    if (isExporting) {
      const requestedCount = indices.length;
      const failureCount = failures.length;
      const warningCount = warnings.length;

      // Overall outcome is classified purely from the completed count:
      // failures/warnings can coexist with a full completion (warnings) or
      // a partial one, so the count alone decides complete/partial/failed.
      // This classification only drives supportLogReason (internal
      // diagnostics) — the page builds the user-facing message/tooltip
      // itself from the structured completedCount/requestedCount/failures/
      // warnings below (see exportPanelMain.js's buildExportOutcomeMessage),
      // so that wording can change without a plugin update.
      if (completedCount === requestedCount) {
        supportLogReason = warningCount ? "export_warnings" : "export_finished";
      } else if (completedCount > 0) {
        supportLogReason = "export_partial";
      } else {
        supportLogReason = "export_failed_pages";
      }

      postToPage("exportResult", { completedCount, requestedCount, failures, warnings });
      supportLog.info("export_finished", {
        requestedCount,
        completedCount,
        failureCount,
        warningCount,
        failures,
        warnings
      }, { pinned: true });
    }
  } catch (e) {
    exportError = e;
    supportLogReason = "export_error";
    supportLog.error("export_failed", { message: e.message, stack: e.stack || "" }, { pinned: true });
    postToPage("exportResult", { statusType: "error", message: `Error: ${e.message}`, tooltip: "" });
  } finally {
    // If the loop exited early with no thrown error and no partial-failure
    // reason already recorded, the only remaining explanation is a user cancel.
    if (!isExporting && !exportError && supportLogReason !== "export_warnings" && supportLogReason !== "export_partial" && supportLogReason !== "export_failed_pages") supportLogReason = "export_cancelled";
    isExporting = false;
    await deleteProcessingTempFolder(processingTempFolder, processingTempRootFolder, processingTempLocation);
    await writeSupportLogFile(supportLogReason);
  }
}

// Exports a single page as a standalone .indd file by duplicating it into a
// throwaway document (much cheaper than saving/subsetting the whole source
// document) and saving that document to the destination path.
async function exportPageAsIndd(doc, pg, outPath, baseName) {
  // Use page.duplicate() into a new document — fast native InDesign operation
  const newDoc = app.documents.add(false);

  newDoc.documentPreferences.intent = app.activeDocument.documentPreferences.intent;
  newDoc.transparencyPreferences.blendingSpace = app.activeDocument.transparencyPreferences.blendingSpace;
  newDoc.viewPreferences.horizontalMeasurementUnits = app.activeDocument.viewPreferences.horizontalMeasurementUnits;
  newDoc.viewPreferences.verticalMeasurementUnits = app.activeDocument.viewPreferences.verticalMeasurementUnits;

  try {
    // Match page size to source page.
    // Use raw bounds in the doc's native unit — measurement units are already
    // copied above, so InDesign interprets these values in the correct unit.
    // (Converting to points and then passing them would cause "out of range"
    // errors when the document unit is inches or mm.)
    const b = pg.bounds;
    const wRaw = Math.abs(Number(b[3]) - Number(b[1]));
    const hRaw = Math.abs(Number(b[2]) - Number(b[0]));
    supportLog.info("indd_temp_document_size", { wRaw, hRaw });
    newDoc.documentPreferences.pageWidth = wRaw;
    newDoc.documentPreferences.pageHeight = hRaw;

    // Duplicate the source page into the new document
    pg.duplicate(LocationOptions.AFTER, newDoc.pages.item(0));

    // Remove the blank first page that was created with the new doc
    if (newDoc.pages.length > 1) {
      newDoc.pages.item(0).remove();
    }

    // Save as .indd
    const savePath = `${outPath}/${baseName}.indd`;
    await newDoc.save(savePath);

    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  } finally {
    try { newDoc.close(SaveOptions.NO); } catch (e) { }
  }
}

// Exports a single page from the original document to a temp file, in PNG
// or max-quality JPEG, as the source image the WASM codec will subsequently
// resize/recompress/convert.
async function exportPageToTmpFile(doc, pageNumber, tmpPath, isPng, exportDpi, pngTransparent) {
  const absPageString = `+${pageNumber}`;

  supportLog.info("image_temp_export_from_original_doc", {
    pageNumber,
    isPng,
    exportDpi,
    tmpPath
  });

  if (isPng) {
    const pp = app.pngExportPreferences;
    pp.exportResolution = exportDpi;
    pp.transparentBackground = pngTransparent;
    pp.antiAlias = true;
    pp.pngExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
    pp.pageString = absPageString;

    doc.exportFile(ExportFormat.PNG_FORMAT, tmpPath, false);
  } else {
    const jp = app.jpegExportPreferences;
    jp.exportResolution = exportDpi;
    jp.jpegQuality = JPEGOptionsQuality.MAXIMUM;
    jp.antiAlias = true;
    jp.jpegExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
    jp.pageString = absPageString;

    doc.exportFile(ExportFormat.JPG, tmpPath, false);
  }
}

// Tears down a processing-temp session folder after export: deletes its
// contents, then the session folder itself, and finally its parent root
// folder too if that's now empty. Best-effort throughout — every failure is
// logged but non-fatal, since leftover temp files are a cleanliness issue,
// not an export-correctness one.
async function deleteProcessingTempFolder(folder, rootFolder, location) {
  if (!folder) return;

  const folderPath = folder.nativePath || "";

  try {
    const entries = await folder.getEntries();

    supportLog.info("processing_temp_cleanup_started", {
      location: location || "",
      path: folderPath,
      count: entries.length,
      entries: entries.map(e => e.name || e.nativePath || "")
    });

    for (const entry of entries) {
      try {
        await entry.delete();

        supportLog.info("processing_temp_entry_deleted", {
          location: location || "",
          entry: entry.name || entry.nativePath || ""
        });
      } catch (entryErr) {
        supportLog.warn("processing_temp_entry_delete_failed", {
          location: location || "",
          entry: entry.name || entry.nativePath || "",
          message: entryErr.message
        });
      }
    }

    // Give the filesystem a moment to settle before checking whether the
    // deletes actually took effect (same caution as the temp-file read path).
    await delay(150);

    const remaining = await folder.getEntries();

    supportLog.info("processing_temp_cleanup_finished", {
      location: location || "",
      path: folderPath,
      remainingCount: remaining.length,
      remainingEntries: remaining.map(e => e.name || e.nativePath || "")
    });

    if (!remaining.length) {
      try {
        await delay(150);
        await folder.delete();

        supportLog.info("processing_temp_session_folder_deleted", {
          location: location || "",
          path: folderPath
        });
      } catch (deleteErr) {
        supportLog.warn("processing_temp_session_folder_delete_failed", {
          location: location || "",
          path: folderPath,
          message: deleteErr.message
        });
      }

      if (rootFolder) {
        let rootPath = "";
        try { rootPath = rootFolder.nativePath || ""; } catch (_) {}
        try {
          const rootEntries = await rootFolder.getEntries();
          if (!rootEntries.length) {
            await rootFolder.delete();
            supportLog.info("processing_temp_root_folder_deleted", {
              location: location || "",
              path: rootPath
            });
          }
        } catch (rootErr) {
          supportLog.warn("processing_temp_root_folder_delete_failed", {
            location: location || "",
            path: rootPath,
            message: rootErr.message
          });
        }
      }
    }

  } catch (err) {
    supportLog.warn("processing_temp_cleanup_failed", {
      location: location || "",
      path: folderPath,
      message: err.message,
      stack: err.stack || ""
    });
  }
}

module.exports = { init };
