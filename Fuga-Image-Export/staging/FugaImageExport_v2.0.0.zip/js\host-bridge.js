/**
 * Action-message bridge between the UXP host and the export-ui webview
 * (the web2print page). Owns everything only InDesign/UXP can do: document
 * access, temp-file I/O, and export orchestration. The page owns the form UI
 * and sends/receives plain {action, ...} messages — see PLAN.md for the
 * action table.
 */
const { app, ExportFormat, ExportRangeOrAllPages, JPEGOptionsQuality, SaveOptions, LocationOptions } = require("indesign");
const base64 = require("./base64.js");
const license = require("./license.js");
const supportLog = require("./support-log.js");

function getFS() { return require("uxp").storage.localFileSystem; }
function getStorage() { return require("uxp").storage; }

// Hard safety ceiling — never exceeded regardless of what the page requests
// via settings.maxSourceMp, to protect against a bad web-side config causing
// memory pressure. This is the one number that genuinely needs a plugin
// update to raise; everything else below is page-tunable up to it.
const HARD_MAX_PROCESSING_SOURCE_MP = 40;
const MAX_STATUS_TOOLTIP_ITEMS = 8;
const MAX_STATUS_TOOLTIP_ITEM_CHARS = 140;

// Fallback defaults, used only when the page doesn't send its own values —
// keeps this host working standalone/backward-compatibly. The page (see
// exportPanelMain.js) is the intended source of truth for these; edit them
// there, not here, to change behavior without a plugin update.
const DEFAULT_QUALITY_PERCENT = { low: 45, medium: 65, high: 80, maximum: 92 };
const DEFAULT_OVERSAMPLE_THRESHOLDS = [
  { maxShortPx: 600, mult: 4 },
  { maxShortPx: 1600, mult: 2 }
];
const DEFAULT_FILENAME_TEMPLATE = "{prefix}_{doc}_{size}_{page}_{suffix}";

function resolveQualityPercent(settings) {
  const sent = Number(settings.qualityPercent);
  if (Number.isFinite(sent) && sent > 0) return sent;
  return DEFAULT_QUALITY_PERCENT[settings.quality] || DEFAULT_QUALITY_PERCENT.high;
}

function resolveOversampleThresholds(settings) {
  const sent = settings.oversampleThresholds;
  if (Array.isArray(sent) && sent.length && sent.every(t => t && Number.isFinite(t.maxShortPx) && Number.isFinite(t.mult))) {
    return sent.slice().sort((a, b) => a.maxShortPx - b.maxShortPx);
  }
  return DEFAULT_OVERSAMPLE_THRESHOLDS;
}

function resolveMaxSourceMp(settings) {
  const sent = Number(settings.maxSourceMp);
  if (Number.isFinite(sent) && sent > 0) return Math.min(sent, HARD_MAX_PROCESSING_SOURCE_MP);
  return HARD_MAX_PROCESSING_SOURCE_MP;
}

function resolveFilenameTemplate(settings) {
  return (typeof settings.filenameTemplate === "string" && settings.filenameTemplate.trim())
    ? settings.filenameTemplate
    : DEFAULT_FILENAME_TEMPLATE;
}

function applyFilenameTemplate(template, values) {
  const filled = template.replace(/\{(\w+)\}/g, (_, key) => (values[key] || ""));
  const collapsed = filled.replace(/_+/g, "_").replace(/^_+|_+$/g, "");
  return collapsed || values.doc || "export";
}

class ExportCancelledError extends Error {
  constructor(message = "Export cancelled") {
    super(message);
    this.name = "ExportCancelledError";
  }
}

let webview = null;
let codecBridge = null;
let isExporting = false;
let currentRequestId = null;
let outputFolderEntry = null;
let licenseStatus = { ok: false, message: "Checking license..." };
let exportStatusBase = "";
let exportStatusDetail = "";

function init(exportUiWebview, wasmCodecBridge) {
  webview = exportUiWebview;
  codecBridge = wasmCodecBridge;
  window.addEventListener("message", (e) => handleMessage(e.data));
  initializeLicense();
}

function postToPage(action, payload) {
  if (!webview) return;
  webview.postMessage(Object.assign({ action }, payload || {}), "*");
}

function setStatusDetail(msg) {
  exportStatusDetail = msg || "";
  postProgress();
}

async function handleMessage(data) {
  if (!data || !data.action) return;

  switch (data.action) {
    case "ready":
      supportLog.info("export_ui_ready", {}, { pinned: true });
      postToPage("init", {
        version: getPanelVersion(),
        license: licenseStatus,
        document: getDocumentInfoPayload()
      });
      break;
    case "getDocumentInfo":
      postToPage("documentInfo", getDocumentInfoPayload());
      break;
    case "browseFolder":
      await handleBrowseFolder();
      break;
    case "getSupportLogPath":
      postToPage("supportLogPath", { path: await resolveSupportLogPath() });
      break;
    case "runExport":
      await handleRunExport(data);
      break;
    case "cancelExport":
      handleCancelExport();
      break;
  }
}

// ── LICENSE ───────────────────────────────────────────────────────
async function initializeLicense() {
  supportLog.info("license_check_started", {});
  licenseStatus = await license.checkLicense();
  supportLog.info("license_check_finished", {
    ok: !!licenseStatus.ok,
    expired: !!licenseStatus.expired,
    message: licenseStatus.message || "",
    timeSource: licenseStatus.timeSource || "",
    effectiveExpiresAt: licenseStatus.effectiveExpiresAt || ""
  }, { pinned: true });
  postToPage("licenseStatus", licenseStatus);
}

function isLicenseValid() {
  return !!(licenseStatus && licenseStatus.ok);
}

// ── DOCUMENT INFO ─────────────────────────────────────────────────
function getDocumentInfoPayload() {
  try {
    const doc = app.activeDocument;
    return {
      name: doc.name.replace(/\.[^.]+$/, ""),
      pageCount: doc.pages.length,
      unit: resolveDocUnit(doc)
    };
  } catch (e) {
    return { name: "DocumentName", pageCount: 0, unit: "px" };
  }
}

function resolveDocUnit(doc) {
  const mu = doc.viewPreferences.horizontalMeasurementUnits.toString();
  if (mu === "MILLIMETERS") return "mm";
  if (mu === "INCHES" || mu === "INCHES_DECIMAL") return "in";
  return "px";
}

// ── FOLDER BROWSE ─────────────────────────────────────────────────
async function handleBrowseFolder() {
  try {
    const folder = await getFS().getFolder();
    if (folder) {
      outputFolderEntry = folder;
      supportLog.info("output_folder_selected", { path: folder.nativePath });
      postToPage("folderSelected", { path: folder.nativePath });
    } else {
      supportLog.info("output_folder_selection_cancelled", {});
      postToPage("folderSelected", { cancelled: true });
    }
  } catch (e) {
    supportLog.error("output_folder_selection_failed", { message: e.message, stack: e.stack || "" });
    postToPage("folderSelected", { cancelled: true });
  }
}

// ── EXPORT / CANCEL ───────────────────────────────────────────────
function handleCancelExport() {
  if (!isExporting) return;
  supportLog.warn("export_cancel_requested", { requestId: currentRequestId || null });
  isExporting = false;
  if (currentRequestId && codecBridge) codecBridge.cancelRequest(currentRequestId);
  setStatusBase("Cancelling export...");
}

async function handleRunExport(settings) {
  if (!isLicenseValid()) {
    supportLog.warn("export_blocked_by_license", licenseStatus || {});
    postToPage("exportResult", { statusType: "error", message: licenseStatus.message || "License is invalid.", tooltip: "" });
    return;
  }
  if (!outputFolderEntry) {
    postToPage("exportResult", { statusType: "error", message: "No output folder selected.", tooltip: "" });
    return;
  }
  if (settings.format !== "indd" && (!codecBridge || !codecBridge.isReady)) {
    supportLog.error("export_blocked_webview_not_ready", getExportSettingsSnapshot(settings));
    postToPage("exportResult", { statusType: "error", message: "WebView bridge not ready.", tooltip: "" });
    await writeSupportLogFile("webview_not_ready");
    return;
  }

  await doExport(settings);
}

function getPanelVersion() {
  const el = document.querySelector(".header-version");
  return el ? el.textContent.trim() : "";
}

function getExportSettingsSnapshot(settings) {
  return {
    version: getPanelVersion(),
    format: settings.format,
    dpi: settings.dpi,
    pageRange: settings.pageRange,
    pageRangeText: settings.pageRangeText || "",
    quality: settings.quality,
    maxKB: settings.maxKB,
    smartOversample: settings.smartOversample,
    includeSize: settings.includeSize,
    includePageNum: settings.includePageNum,
    includePrefix: settings.includePrefix,
    hasCustomPrefix: !!settings.customPrefix,
    includeSuffix: settings.includeSuffix,
    hasCustomSuffix: !!settings.customSuffix,
    outputPath: outputFolderEntry ? outputFolderEntry.nativePath : ""
  };
}

// ── HELPERS ───────────────────────────────────────────────────────
function sanitize(s) { return s.replace(/[\/\\:*?"<>|]/g, "_"); }

function joinNativePath(folderPath, fileName) {
  const separator = folderPath.includes("\\") ? "\\" : "/";
  return folderPath.replace(/[\\\/]+$/, "") + separator + fileName;
}

function nativePathToFileUrl(path) {
  // Some platforms/entries (observed on macOS with security-scoped folders)
  // report `nativePath` as an already percent-encoded file:// URL rather
  // than a raw OS path. Re-encoding that would double-encode it (%25..).
  if (/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//.test(path)) {
    return path;
  }

  const normalized = path.replace(/\\/g, "/");
  const encoded = normalized
    .split("/")
    .map((segment) => (/^[A-Za-z]:$/.test(segment) ? segment : encodeURIComponent(segment)))
    .join("/");

  if (/^[A-Za-z]:\//.test(normalized)) {
    return "file:///" + encoded;
  }

  if (normalized.startsWith("//")) {
    return "file:" + encoded;
  }

  if (normalized.startsWith("/")) {
    return "file://" + encoded;
  }

  return "file:///" + encoded;
}

function normalizeNativePathForCompare(path) {
  return String(path || "")
    .replace(/\\/g, "/")
    .replace(/\/+$/, "")
    .toLowerCase();
}

function nativePathsMatch(left, right) {
  const normalizedLeft = normalizeNativePathForCompare(left);
  const normalizedRight = normalizeNativePathForCompare(right);
  return !!normalizedLeft && !!normalizedRight && normalizedLeft === normalizedRight;
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function getFileEntryByNativePath(path) {
  return await getFS().getEntryWithUrl(nativePathToFileUrl(path));
}

async function tryReadBinaryFile(file, storage) {
  const binary = await file.read({ format: storage.formats.binary });
  const bytes = binary && (binary.byteLength || binary.length || 0);
  return { binary, bytes };
}

async function verifyStableBinaryRead(file, storage, expectedBytes, context) {
  await delay(100);
  const secondRead = await tryReadBinaryFile(file, storage);
  if (secondRead.bytes !== expectedBytes) {
    throw new Error(`Temporary file size changed after read (${expectedBytes} -> ${secondRead.bytes})`);
  }

  supportLog.info("temp_file_read_stable", {
    label: context.label,
    fileName: context.fileName,
    source: context.source,
    folderPath: context.folderPath,
    nativePath: context.nativePath,
    bytes: secondRead.bytes
  });
  return secondRead.binary;
}

async function readExportedBinaryFile(options) {
  const folder = options.folder;
  const fileName = options.fileName;
  const label = options.label;
  const nativePath = options.nativePath || "";
  const preferredFile = options.preferredFile || null;
  const storage = getStorage();
  let lastError = null;
  const lastErrorsBySource = {};

  const fileBaseName = fileName.replace(/\.[^.]+$/, "");

  for (let attempt = 1; attempt <= 25; attempt++) {
    if (!isExporting) {
      throw new ExportCancelledError();
    }

    const candidates = [];
    if (preferredFile) candidates.push({ source: "preferredFile", getFile: async () => preferredFile });
    candidates.push({ source: "folderEntry", getFile: async () => await folder.getEntry(fileName) });
    if (nativePath) {
      candidates.push({ source: "nativePathFileUrl", getFile: async () => await getFileEntryByNativePath(nativePath) });
    }
    candidates.push({ source: "folderScan", getFile: async () => {
      const entries = await folder.getEntries();
      const match = entries.find(e => e.isFile && e.name.startsWith(fileBaseName));
      if (!match) throw new Error(`No file starting with '${fileBaseName}' found in temp folder`);
      return match;
    }});

    for (const candidate of candidates) {
      try {
        const file = await candidate.getFile();
        const result = await tryReadBinaryFile(file, storage);
        if (result.bytes > 0) {
          const stableBinary = await verifyStableBinaryRead(file, storage, result.bytes, {
            label,
            fileName,
            source: candidate.source,
            folderPath: folder.nativePath || "",
            nativePath
          });
          if (attempt > 1 || candidate.source !== "preferredFile") {
            supportLog.info("temp_file_read_retry_succeeded", {
              label,
              fileName,
              attempt,
              source: candidate.source,
              folderPath: folder.nativePath || "",
              nativePath,
              bytes: result.bytes
            });
          }
          return { file, binary: stableBinary };
        }

        lastError = new Error("Temporary export file is empty");
        lastErrorsBySource[candidate.source] = { message: lastError.message, code: null };
      } catch (err) {
        lastError = err;
        // err.code (e.g. EBUSY/EACCES/EPERM/ENOENT on some platforms) is the
        // one signal that can tell a transient AV/cloud-sync lock apart from
        // a genuine permission problem — capture it alongside the message
        // wherever a temp-file read/probe fails, purely for diagnosing the
        // mac/Windows "written but not readable" cases from support logs.
        lastErrorsBySource[candidate.source] = { message: err.message, code: err.code || null };
        if (attempt === 1) {
          supportLog.warn("temp_file_read_candidate_failed", {
            label,
            fileName,
            source: candidate.source,
            folderPath: folder.nativePath || "",
            nativePath,
            message: err.message,
            code: err.code || null
          });
        }
      }
    }

    await delay(Math.min(100 + attempt * 25, 400));
  }

  supportLog.error("temp_file_read_failed", {
    label,
    fileName,
    folderPath: folder.nativePath || "",
    nativePath,
    lastErrorsBySource
  });
  throw new Error(`${label} could not be read (${fileName}): ${lastError ? lastError.message : "unknown error"}`);
}

async function probeProcessingTempFolder(folder, location) {
  const storage = getStorage();
  const probeName = `probe_${Date.now()}.bin`;
  let probeFile = null;

  try {
    probeFile = await folder.createFile(probeName, { overwrite: true });
    const probeBytes = new Uint8Array([70, 85, 71, 65]);
    await probeFile.write(probeBytes, { format: storage.formats.binary });

    const result = await tryReadBinaryFile(probeFile, storage);
    if (result.bytes !== probeBytes.length) {
      throw new Error(`Probe read returned ${result.bytes} byte(s), expected ${probeBytes.length}`);
    }

    supportLog.info("processing_temp_folder_probe_succeeded", {
      location,
      path: folder.nativePath || "",
      probeFile: probeName
    });
  } catch (err) {
    supportLog.warn("processing_temp_folder_probe_failed", {
      location,
      path: folder && folder.nativePath ? folder.nativePath : "",
      message: err.message,
      code: err.code || null
    });
    throw err;
  } finally {
    if (probeFile) {
      try { await probeFile.delete(); } catch (err) { }
    }
  }
}

async function exportProbeImageToTmpFile(tmpPath) {
  const newDoc = app.documents.add(false);
  try {
    newDoc.documentPreferences.pageWidth = 12;
    newDoc.documentPreferences.pageHeight = 12;

    const pageLabel = newDoc.pages.item(0).name;
    const jp = app.jpegExportPreferences;
    jp.exportResolution = 72;
    jp.jpegQuality = JPEGOptionsQuality.LOW;
    jp.antiAlias = true;
    jp.jpegExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
    jp.pageString = pageLabel;
    newDoc.exportFile(ExportFormat.JPG, tmpPath, false);
  } finally {
    try { newDoc.close(SaveOptions.NO); } catch (e) { }
  }
}

async function probeInDesignTempExport(folder, location) {
  const probeName = "probe.jpg";
  const fallbackPath = joinNativePath(folder.nativePath || "", probeName);
  let probeFile = null;
  let probePath = fallbackPath;

  try {
    probeFile = await folder.createFile(probeName, { overwrite: true });
    probePath = probeFile.nativePath || fallbackPath;
    supportLog.info("processing_temp_folder_indesign_probe_started", {
      location,
      folderPath: folder.nativePath || "",
      fileName: probeName,
      path: probePath
    });

    await exportProbeImageToTmpFile(probePath);
    const result = await readExportedBinaryFile({
      folder,
      fileName: probeName,
      label: `${location} InDesign temp export probe`,
      nativePath: probePath,
      preferredFile: probeFile
    });
    probeFile = result.file;
    supportLog.info("processing_temp_folder_indesign_probe_succeeded", {
      location,
      folderPath: folder.nativePath || "",
      fileName: probeName,
      path: probePath,
      bytes: result.binary.byteLength || result.binary.length || null
    });
  } catch (err) {
    supportLog.warn("processing_temp_folder_indesign_probe_failed", {
      location,
      folderPath: folder && folder.nativePath ? folder.nativePath : "",
      fileName: probeName,
      path: probePath,
      message: err.message,
      code: err.code || null
    });
    throw err;
  } finally {
    if (probeFile) {
      try { await deleteFileAtPath(folder, probeName, probeFile); } catch (err) { }
    }
  }
}

async function createAndProbeProcessingTempFolder(parentFolder, location) {
  supportLog.info("processing_temp_folder_candidate_started", {
    location,
    parentPath: parentFolder.nativePath || ""
  });

  let rootFolder = null;

  try {
    rootFolder = await parentFolder.getEntry("FugaImageExport_Temp");
  } catch (e) {
    rootFolder = await parentFolder.createFolder("FugaImageExport_Temp");
  }

  const folder = await rootFolder.createFolder(`session_${Date.now()}`, { overwrite: true });

  try {
    await probeProcessingTempFolder(folder, location);

    try {
      await probeInDesignTempExport(folder, location);
    } catch (err) {
      supportLog.warn("processing_temp_folder_indesign_probe_non_fatal", {
        location,
        path: folder.nativePath || "",
        message: err.message
      });
    }

    supportLog.info("processing_temp_folder_created", {
      location,
      parentPath: parentFolder.nativePath || "",
      path: folder.nativePath || ""
    });

    return { folder, rootFolder, location, path: folder.nativePath || "" };
  } catch (err) {
    try { await folder.delete(); } catch (deleteErr) { }
    throw err;
  }
}

async function getProcessingTempFolder(fs, outputFolder, excludedLocations) {
  // Prefer locations outside the user's chosen output folder: it is often a
  // cloud-synced path (iCloud Desktop, OneDrive, Dropbox, Google Drive), and
  // those sync daemons intermittently evict/relock files right after they're
  // written, which a one-time startup probe won't catch under real export
  // load. Keep outputFolder only as a last-resort fallback.
  let attempts = [
    { location: "temporaryFolder", getParent: async () => await fs.getTemporaryFolder() },
    { location: "dataFolder", getParent: async () => await fs.getDataFolder() }
  ];

  if (outputFolder) {
    attempts.push({
      location: "outputFolder",
      getParent: async () => outputFolder
    });
  }

  if (excludedLocations && excludedLocations.size) {
    const remaining = attempts.filter(attempt => !excludedLocations.has(attempt.location));
    // If exclusions would wipe out every candidate, ignore them rather than
    // fail outright — a previously-flaky location is still better than none.
    if (remaining.length) attempts = remaining;
  }

  const errors = [];

  for (const attempt of attempts) {
    try {
      const parentFolder = await attempt.getParent();
      return await createAndProbeProcessingTempFolder(parentFolder, attempt.location);
    } catch (err) {
      errors.push(`${attempt.location}: ${err.message}`);
      supportLog.warn("processing_temp_folder_candidate_failed", {
        location: attempt.location,
        message: err.message,
        code: err.code || null
      });
    }
  }

  throw new Error(`Could not create a readable temporary processing folder. ${errors.join("; ")}`);
}

async function deleteFileAtPath(folder, fileName, fileEntry) {
  if (fileEntry) {
    try {
      await fileEntry.delete();
      return;
    } catch (err) {
      // InDesign may replace the file after UXP first resolves it; retry by path.
    }
  }

  const freshEntry = await folder.getEntry(fileName);
  await freshEntry.delete();
}

function toPoints(val, unit) {
  if (unit === "mm") return val / 0.352778;
  if (unit === "in") return val * 72;
  return val;
}

function ptToUnit(pt, unit, dpi) {
  if (unit === "px") return Math.round(pt * (dpi / 72));
  if (unit === "in") return Math.round(pt * 100) / 100;
  if (unit === "mm") return Math.round(pt * 10) / 10;
  return pt;
}

// For INDD exports — size in mm instead of pixels
function buildFilenameIndd(settings, docName, wMm, hMm, pageLabel) {
  const values = {
    prefix: (settings.includePrefix && settings.customPrefix) ? sanitize(settings.customPrefix) : "",
    doc: sanitize(docName),
    size: settings.includeSize ? `${wMm}x${hMm}` : "",
    page: settings.includePageNum ? `p${sanitize(pageLabel)}` : "",
    suffix: (settings.includeSuffix && settings.customSuffix) ? sanitize(settings.customSuffix) : ""
  };
  return applyFilenameTemplate(resolveFilenameTemplate(settings), values);
}

function buildFilename(settings, docName, unit, wPt, hPt, pageLabel) {
  const values = {
    prefix: (settings.includePrefix && settings.customPrefix) ? sanitize(settings.customPrefix) : "",
    doc: sanitize(docName),
    size: settings.includeSize ? `${ptToUnit(wPt, unit, 72)}x${ptToUnit(hPt, unit, 72)}` : "",
    page: settings.includePageNum ? `p${sanitize(pageLabel)}` : "",
    suffix: (settings.includeSuffix && settings.customSuffix) ? sanitize(settings.customSuffix) : ""
  };
  return applyFilenameTemplate(resolveFilenameTemplate(settings), values);
}

function getPageIndices(doc, settings) {
  const total = doc.pages.length;
  if (settings.pageRange === "all") return Array.from({ length: total }, (_, i) => i);
  const indices = [];
  const parts = String(settings.pageRangeText || "").split(",");
  for (const part of parts) {
    const p = part.trim();
    if (p.includes("-")) {
      const [s, e] = p.split("-").map(n => parseInt(n) - 1);
      for (let i = s; i <= e && i < total; i++) if (i >= 0) indices.push(i);
    } else {
      const i = parseInt(p) - 1;
      if (i >= 0 && i < total) indices.push(i);
    }
  }
  return indices;
}

function getPage(doc, idx) { return doc.pages.item(idx); }

function getOversampleMult(settings, wPt, hPt) {
  if (!settings.smartOversample) return 1;
  const shortPx = Math.round(Math.min(wPt, hPt) * (settings.dpi / 72));
  const thresholds = resolveOversampleThresholds(settings);
  for (const t of thresholds) {
    if (shortPx < t.maxShortPx) return t.mult;
  }
  return 1;
}

function getProcessingExportPlan(settings, wPt, hPt) {
  const maxSourceMp = resolveMaxSourceMp(settings);
  const mult = getOversampleMult(settings, wPt, hPt);
  const baseWidth = Math.round(wPt * (settings.dpi / 72));
  const baseHeight = Math.round(hPt * (settings.dpi / 72));
  const baseMp = (baseWidth * baseHeight) / 1000000;
  const sourceMp = (baseWidth * mult * baseHeight * mult) / 1000000;

  if (sourceMp <= maxSourceMp) {
    return {
      exportDpi: settings.dpi * mult,
      targetWidth: baseWidth,
      targetHeight: baseHeight,
      sourceWidth: baseWidth * mult,
      sourceHeight: baseHeight * mult,
      sourceMp,
      oversampleMultiplier: mult
    };
  }

  if (baseMp <= maxSourceMp) {
    const safeMult = Math.max(1, Math.floor(Math.sqrt((maxSourceMp * 1000000) / (baseWidth * baseHeight))));
    supportLog.warn("oversample_limited_by_source_size", {
      requestedMultiplier: mult,
      appliedMultiplier: safeMult,
      requestedDpi: settings.dpi,
      exportDpi: settings.dpi * safeMult,
      targetWidth: baseWidth,
      targetHeight: baseHeight,
      sourceMp,
      maxSourceMp
    });
    return {
      exportDpi: settings.dpi * safeMult,
      targetWidth: baseWidth,
      targetHeight: baseHeight,
      sourceWidth: baseWidth * safeMult,
      sourceHeight: baseHeight * safeMult,
      sourceMp: (baseWidth * safeMult * baseHeight * safeMult) / 1000000,
      oversampleMultiplier: safeMult
    };
  }

  const scale = Math.sqrt((maxSourceMp * 1000000) / (baseWidth * baseHeight));
  const exportDpi = Math.max(1, Math.floor(settings.dpi * scale));
  const targetWidth = Math.max(1, Math.round(wPt * (exportDpi / 72)));
  const targetHeight = Math.max(1, Math.round(hPt * (exportDpi / 72)));

  supportLog.warn("oversample_limited_by_source_size", {
    requestedMultiplier: mult,
    appliedMultiplier: 1,
    requestedDpi: settings.dpi,
    exportDpi,
    targetWidth,
    targetHeight,
    sourceMp: baseMp,
    maxSourceMp
  });
  return {
    exportDpi,
    targetWidth,
    targetHeight,
    sourceWidth: targetWidth,
    sourceHeight: targetHeight,
    sourceMp: (targetWidth * targetHeight) / 1000000,
    oversampleMultiplier: 1
  };
}

function getJpegQuality(q) {
  const map = { "low": JPEGOptionsQuality.LOW, "medium": JPEGOptionsQuality.MEDIUM, "high": JPEGOptionsQuality.HIGH, "maximum": JPEGOptionsQuality.MAXIMUM };
  return map[q] || JPEGOptionsQuality.HIGH;
}

function getEffectiveMaxKB(settings) {
  return settings.format === "png" || settings.format === "indd" ? 0 : settings.maxKB;
}

function classifyProcessedExportError(err) {
  const message = err && err.message ? err.message : "unknown error";
  if (/could not be read|Temporary export file|Temporary file size changed/i.test(message)) {
    return `Temp file read failed - ${message}`;
  }
  if (/exportFile|export/i.test(message)) {
    return `Temp export failed - ${message}`;
  }
  return `Processing failed - ${message}`;
}

// ── STATUS TEXT (built here, pushed to the page as plain strings) ──
function setStatusBase(msg) {
  exportStatusBase = msg || "";
  exportStatusDetail = "";
  postProgress();
}

function composeStatusMessage() {
  if (exportStatusBase && exportStatusDetail) {
    return `${exportStatusBase} ${exportStatusDetail}`;
  }
  return exportStatusBase || exportStatusDetail;
}

let lastProgressPercent = 0;
function postProgress(percent) {
  if (typeof percent === "number") lastProgressPercent = percent;
  postToPage("exportProgress", { percent: lastProgressPercent, message: composeStatusMessage() });
}

function truncateStatusTooltipItem(item) {
  const text = String(item || "").replace(/\s+/g, " ").trim();
  if (text.length <= MAX_STATUS_TOOLTIP_ITEM_CHARS) return text;
  return text.slice(0, MAX_STATUS_TOOLTIP_ITEM_CHARS - 3) + "...";
}

function appendStatusTooltipGroup(lines, label, items, remainingSlots) {
  if (!items.length || remainingSlots <= 0) return 0;

  lines.push(`${label} (${items.length}):`);
  const shown = Math.min(items.length, remainingSlots);
  for (let i = 0; i < shown; i++) {
    lines.push(`- ${truncateStatusTooltipItem(items[i])}`);
  }
  if (items.length > shown) {
    lines.push(`- ...and ${items.length - shown} more`);
  }
  return shown;
}

function buildExportOutcomeTooltip(failures, warnings) {
  const failureItems = Array.isArray(failures) ? failures : [];
  const warningItems = Array.isArray(warnings) ? warnings : [];
  if (!failureItems.length && !warningItems.length) return "";

  const lines = [];
  let remainingSlots = MAX_STATUS_TOOLTIP_ITEMS;
  const failuresShown = appendStatusTooltipGroup(lines, "Failures", failureItems, remainingSlots);
  remainingSlots -= failuresShown;
  if (failureItems.length && warningItems.length) lines.push("");
  appendStatusTooltipGroup(lines, "Warnings", warningItems, remainingSlots);
  return lines.join("\n");
}

// ── DIAGNOSTICS ───────────────────────────────────────────────────
function getRuntimeSnapshot(fs) {
  let supportedDomains = [];
  try {
    if (fs && fs.supportedDomains && typeof fs.supportedDomains.map === "function") {
      supportedDomains = fs.supportedDomains.map(domain => String(domain));
    }
  } catch (err) {
    supportedDomains = [`error: ${err.message}`];
  }

  return {
    appName: app && app.name ? app.name : "",
    appVersion: app && app.version ? app.version : "",
    panelVersion: getPanelVersion(),
    manifestVersion: 5,
    localFileSystemPermission: "fullAccess",
    userAgent: typeof navigator !== "undefined" ? navigator.userAgent : "",
    platform: typeof navigator !== "undefined" ? navigator.platform || "" : "",
    language: typeof navigator !== "undefined" ? navigator.language || "" : "",
    supportedDomains
  };
}

function getDocumentSnapshot(doc) {
  try {
    return {
      name: doc.name || "",
      pages: doc.pages ? doc.pages.length : null,
      horizontalMeasurementUnits: doc.viewPreferences && doc.viewPreferences.horizontalMeasurementUnits
        ? doc.viewPreferences.horizontalMeasurementUnits.toString()
        : ""
    };
  } catch (err) {
    return { error: err.message };
  }
}

async function writeSupportLogFile(reason) {
  try {
    supportLog.info("support_log_write_started", { reason });
    const fs = getStorage().localFileSystem;
    const dataFolder = await fs.getDataFolder();
    const file = await dataFolder.createFile("fuga_image_export.log", { overwrite: true });
    await file.write(supportLog.getText());
    supportLog.info("support_log_write_finished", {
      filename: "fuga_image_export.log",
      location: "dataFolder",
      path: file.nativePath || ""
    });
  } catch (err) {
    supportLog.error("support_log_write_failed", { message: err.message, stack: err.stack || "" });
  }
}

async function resolveSupportLogPath() {
  try {
    const dataFolder = await getStorage().localFileSystem.getDataFolder();
    const basePath = dataFolder.nativePath || "";
    if (basePath) return `${basePath}\\fuga_image_export.log`;
    return "UXP plugin data folder: fuga_image_export.log";
  } catch (err) {
    supportLog.error("support_log_path_resolve_failed", { message: err.message, stack: err.stack || "" });
    return "Could not resolve plugin data folder path. The file is named fuga_image_export.log.";
  }
}

// ── DO EXPORT ─────────────────────────────────────────────────────
async function doExport(settings) {
  let warnings = [];
  let failures = [];
  let exportError = null;
  let supportLogReason = "export_finished";
  let processingTempFolder = null;
  let processingTempRootFolder = null;
  let processingTempLocation = "";
  let consecutiveTempFailures = 0;
  let forceTempFolderReselect = false;
  const excludedTempLocations = new Set();

  isExporting = true;
  exportStatusBase = "";
  exportStatusDetail = "";
  lastProgressPercent = 0;
  setStatusBase("Exporting...");
  supportLog.info("export_started", getExportSettingsSnapshot(settings), { pinned: true });

  try {
    const fs = getFS();
    const doc = app.activeDocument;
    supportLog.info("runtime_snapshot", getRuntimeSnapshot(fs), { pinned: true });
    supportLog.info("document_snapshot", getDocumentSnapshot(doc), { pinned: true });
    const unit = resolveDocUnit(doc);
    const docName = doc.name.replace(/\.[^.]+$/, "");
    const indices = getPageIndices(doc, settings);
    const nameCounts = {};
    const outPath = outputFolderEntry.nativePath;
    const outputFolder = outputFolderEntry;
    let completedCount = 0;

    supportLog.info("export_pages_resolved", {
      requestedRange: settings.pageRange,
      pageRangeText: settings.pageRangeText || "",
      count: indices.length,
      indices: indices.map(index => index + 1)
    });

    for (let i = 0; i < indices.length; i++) {
      if (!isExporting) {
        supportLog.warn("export_loop_stopped", { completedCount, requestedCount: indices.length });
        supportLogReason = "export_cancelled";
        break;
      }

      const pgIdx = indices[i];
      const pg = getPage(doc, pgIdx);
      const b = pg.bounds;
      const hRaw = b[2] - b[0];
      const wRaw = b[3] - b[1];
      const hPt = toPoints(hRaw, unit);
      const wPt = toPoints(wRaw, unit);
      const processingPlan = getProcessingExportPlan(settings, wPt, hPt);
      const mult = processingPlan.oversampleMultiplier;
      const exportDpi = processingPlan.exportDpi;
      const pageLabel = pg.name;

      const targetWidth = processingPlan.targetWidth;
      const targetHeight = processingPlan.targetHeight;

      let baseName = buildFilename(settings, docName, unit, wRaw, hRaw, pageLabel);
      if (nameCounts[baseName] !== undefined) { nameCounts[baseName]++; baseName += "_" + nameCounts[baseName]; }
      else { nameCounts[baseName] = 0; }

      postProgress(Math.round((i / indices.length) * 90));
      setStatusBase(`Exporting page ${pageLabel} of ${indices.length}...`);

      const fmt = settings.format;
      const destPath = `${outPath}/${baseName}.${fmt === "jpg" ? "jpg" : fmt}`;
      const effectiveMaxKB = getEffectiveMaxKB(settings);
      const needsProcessing = fmt === "webp" || effectiveMaxKB > 0 || mult > 1;

      supportLog.info("page_export_started", {
        pageNumber: pgIdx + 1,
        pageLabel,
        format: fmt,
        route: fmt === "indd" ? "indd" : needsProcessing ? "processed_webview" : "direct",
        baseName,
        widthRaw: wRaw,
        heightRaw: hRaw,
        unit,
        targetWidth,
        targetHeight,
        requestedDpi: settings.dpi,
        exportDpi,
        oversampleMultiplier: mult,
        plannedSourceWidth: processingPlan.sourceWidth,
        plannedSourceHeight: processingPlan.sourceHeight,
        plannedSourceMp: processingPlan.sourceMp,
        maxProcessingSourceMp: resolveMaxSourceMp(settings),
        maxKB: effectiveMaxKB
      });

      // ── INDD EXPORT ──
      if (fmt === "indd") {
        const inddName = buildFilenameIndd(settings, docName, wRaw, hRaw, pageLabel);
        const result = await exportPageAsIndd(doc, pg, outPath, inddName);
        if (!result.ok) {
          const failure = `p${pgIdx + 1}: ${result.error}`;
          failures.push(failure);
          supportLog.error("page_export_failed", { pageNumber: pgIdx + 1, failure });
        } else {
          completedCount++;
          supportLog.info("page_export_finished", { pageNumber: pgIdx + 1, format: fmt, file: `${inddName}.indd` });
        }
        continue;
      }

      const absPageString = `+${pgIdx + 1}`;

      if (fmt === "jpg" && !needsProcessing) {
        const jp = app.jpegExportPreferences;
        jp.exportResolution = settings.dpi;
        jp.antiAlias = true;
        jp.jpegExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
        jp.pageString = absPageString;
        jp.jpegQuality = getJpegQuality(settings.quality);
        doc.exportFile(ExportFormat.JPG, destPath, false);
        completedCount++;
        supportLog.info("page_export_finished", { pageNumber: pgIdx + 1, format: fmt, file: `${baseName}.jpg` });

      } else if (fmt === "png" && !needsProcessing) {
        const pp = app.pngExportPreferences;
        pp.exportResolution = settings.dpi;
        pp.transparentBackground = settings.pngTransparent;
        pp.antiAlias = true;
        pp.pngExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
        pp.pageString = absPageString;
        doc.exportFile(ExportFormat.PNG_FORMAT, destPath, false);
        completedCount++;
        supportLog.info("page_export_finished", { pageNumber: pgIdx + 1, format: fmt, file: `${baseName}.png` });

      } else {
        const isPng = fmt === "png";
        const tmpExt = isPng ? "png" : "jpg";
        if (forceTempFolderReselect && processingTempFolder) {
          await deleteProcessingTempFolder(processingTempFolder, processingTempRootFolder, processingTempLocation);
          processingTempFolder = null;
          processingTempRootFolder = null;
          processingTempLocation = "";
        }
        forceTempFolderReselect = false;
        if (!processingTempFolder) {
          const tempSelection = await getProcessingTempFolder(fs, outputFolder, excludedTempLocations);
          processingTempFolder = tempSelection.folder;
          processingTempRootFolder = tempSelection.rootFolder || null;
          processingTempLocation = tempSelection.location;
          supportLog.info("processing_temp_folder_selected", {
            location: processingTempLocation,
            path: tempSelection.path || processingTempFolder.nativePath || ""
          }, { pinned: true });
        }
        const tmpName = `p${pgIdx + 1}.${tmpExt}`;
        const tmpPath = joinNativePath(processingTempFolder.nativePath, tmpName);
        let tmpFile = null;
        let tmpNativePath = tmpPath;

        try {
          tmpFile = await processingTempFolder.createFile(tmpName, { overwrite: true });
          tmpNativePath = tmpFile.nativePath || tmpPath;
          if (tmpFile.nativePath && tmpPath && !nativePathsMatch(tmpFile.nativePath, tmpPath)) {
            supportLog.warn("page_temp_path_mismatch", {
              pageNumber: pgIdx + 1,
              fileName: tmpName,
              plannedPath: tmpPath,
              fileEntryPath: tmpFile.nativePath
            });
          }
          supportLog.info("page_temp_file_precreated", {
            pageNumber: pgIdx + 1,
            fileName: tmpName,
            location: processingTempLocation,
            folderPath: processingTempFolder.nativePath || "",
            path: tmpNativePath
          });

          supportLog.info("page_temp_export_started", {
            pageNumber: pgIdx + 1,
            tmpExt,
            exportDpi,
            plannedSourceWidth: processingPlan.sourceWidth,
            plannedSourceHeight: processingPlan.sourceHeight,
            plannedSourceMp: processingPlan.sourceMp,
            location: processingTempLocation,
            folderPath: processingTempFolder.nativePath || "",
            path: tmpNativePath
          });
          await exportPageToTmpFile(doc, pgIdx + 1, tmpNativePath, isPng, exportDpi, settings.pngTransparent);
          supportLog.info("page_temp_export_finished", {
            pageNumber: pgIdx + 1,
            tmpExt,
            exportDpi,
            location: processingTempLocation,
            folderPath: processingTempFolder.nativePath || "",
            path: tmpNativePath
          });

          await delay(150); // wait if AV holds the temp file

          const exportedTemp = await readExportedBinaryFile({
            folder: processingTempFolder,
            fileName: tmpName,
            label: `page ${pgIdx + 1} temp export`,
            nativePath: tmpNativePath,
            preferredFile: tmpFile
          });
          tmpFile = exportedTemp.file;
          const binary = exportedTemp.binary;
          const inputBase64 = base64.arrToB64(new Uint8Array(binary));
          supportLog.info("page_processing_started", {
            pageNumber: pgIdx + 1,
            inputBytes: binary.byteLength || binary.length || null,
            format: fmt,
            sourceFormat: isPng ? "png" : "jpg",
            quality: effectiveMaxKB > 0 ? 80 : resolveQualityPercent(settings),
            maxKB: effectiveMaxKB,
            targetWidth,
            targetHeight
          });

          const requestPromise = codecBridge.sendRequest("process-image", {
            format: fmt,
            sourceFormat: isPng ? "png" : "jpg",
            quality: effectiveMaxKB > 0 ? 80 : resolveQualityPercent(settings),
            maxKB: effectiveMaxKB,
            targetWidth,
            targetHeight,
            inputBase64
          });

          currentRequestId = requestPromise.requestId;
          const response = await requestPromise;
          supportLog.info("page_processing_finished", {
            pageNumber: pgIdx + 1,
            requestId: currentRequestId,
            info: response.info || {},
            warning: response.warning || ""
          });

          const outputBytes = base64.b64ToArr(response.outputBase64);
          const ext = fmt === "jpg" ? "jpg" : fmt;
          const file = await outputFolder.createFile(`${baseName}.${ext}`, { overwrite: true });
          await file.write(outputBytes, { format: getStorage().formats.binary });
          completedCount++;
          supportLog.info("page_export_finished", {
            pageNumber: pgIdx + 1,
            format: fmt,
            file: `${baseName}.${ext}`,
            outputBytes: outputBytes.length
          });

          const effectiveDpi = Math.round((response.info.width / (wPt / 72)));
          if (effectiveDpi < settings.dpi) {
            supportLog.warn("page_effective_dpi_reduced", {
              pageNumber: pgIdx + 1,
              requestedDpi: settings.dpi,
              effectiveDpi
            });
          }

          if (response.warning) {
            const warning = `p${pgIdx + 1}: ${response.warning}`;
            warnings.push(warning);
            supportLog.warn("page_export_warning", { pageNumber: pgIdx + 1, warning });
          }
        } catch (err) {
          if (err instanceof ExportCancelledError) {
            supportLog.info("page_processing_cancelled", { pageNumber: pgIdx + 1 });
          } else {
            const classified = classifyProcessedExportError(err);
            const failure = `p${pgIdx + 1}: ${classified}`;
            failures.push(failure);
            supportLog.error("page_processing_failed", {
              pageNumber: pgIdx + 1,
              failure,
              message: err.message,
              code: err.code || null,
              stack: err.stack || ""
            });

            const isTempFailure = /^Temp (file read|export) failed/.test(classified);
            if (isTempFailure) {
              consecutiveTempFailures++;
              if (consecutiveTempFailures >= 3 && processingTempLocation) {
                supportLog.warn("processing_temp_folder_switch_triggered", {
                  location: processingTempLocation,
                  path: processingTempFolder ? processingTempFolder.nativePath || "" : "",
                  consecutiveFailures: consecutiveTempFailures
                });
                excludedTempLocations.add(processingTempLocation);
                forceTempFolderReselect = true;
                consecutiveTempFailures = 0;
              }
            } else {
              consecutiveTempFailures = 0;
            }
          }
        } finally {
          currentRequestId = null;
          try {
            await deleteFileAtPath(processingTempFolder, tmpName, tmpFile);
            supportLog.info("page_temp_file_deleted", {
              pageNumber: pgIdx + 1,
              fileName: tmpName,
              location: processingTempLocation,
              folderPath: processingTempFolder.nativePath || "",
              path: tmpNativePath
            });
          } catch (e) {
            supportLog.warn("page_temp_file_delete_failed", {
              pageNumber: pgIdx + 1,
              fileName: tmpName,
              location: processingTempLocation,
              folderPath: processingTempFolder ? processingTempFolder.nativePath || "" : "",
              path: tmpNativePath,
              message: e.message
            });
          }
        }
      }

      if ((i + 1) % 5 === 0 || i === indices.length - 1) {
        await writeSupportLogFile("export_in_progress");
      }
    }

    if (isExporting) {
      const requestedCount = indices.length;
      const failureCount = failures.length;
      const warningCount = warnings.length;
      let msg = "";
      let statusType = "ok";

      if (completedCount === requestedCount) {
        msg = `Export Complete: ${completedCount} file(s) saved.`;
        if (warningCount) {
          msg += ` (${warningCount} warnings)`;
          statusType = "error";
        }
        supportLogReason = warningCount ? "export_warnings" : "export_finished";
      } else if (completedCount > 0) {
        msg = `Export Partial: ${completedCount} of ${requestedCount} file(s) saved.`;
        if (failureCount || warningCount) msg += ` (${failureCount} failed, ${warningCount} warnings)`;
        statusType = "error";
        supportLogReason = "export_partial";
      } else {
        msg = `Export Failed: 0 of ${requestedCount} file(s) saved.`;
        if (failureCount) msg += ` (${failureCount} failed)`;
        statusType = "error";
        supportLogReason = "export_failed_pages";
      }

      postToPage("exportResult", { statusType, message: msg, tooltip: buildExportOutcomeTooltip(failures, warnings) });
      supportLog.info("export_finished", {
        requestedCount,
        completedCount,
        failureCount,
        warningCount,
        failures,
        warnings
      }, { pinned: true });
    }
  } catch (e) {
    exportError = e;
    supportLogReason = "export_error";
    supportLog.error("export_failed", { message: e.message, stack: e.stack || "" }, { pinned: true });
    postToPage("exportResult", { statusType: "error", message: `Error: ${e.message}`, tooltip: "" });
  } finally {
    if (!isExporting && !exportError && supportLogReason !== "export_warnings" && supportLogReason !== "export_partial" && supportLogReason !== "export_failed_pages") supportLogReason = "export_cancelled";
    isExporting = false;
    await deleteProcessingTempFolder(processingTempFolder, processingTempRootFolder, processingTempLocation);
    await writeSupportLogFile(supportLogReason);
  }
}

async function exportPageAsIndd(doc, pg, outPath, baseName) {
  // Use page.duplicate() into a new document — fast native InDesign operation
  const newDoc = app.documents.add(false);

  newDoc.documentPreferences.intent = app.activeDocument.documentPreferences.intent;
  newDoc.transparencyPreferences.blendingSpace = app.activeDocument.transparencyPreferences.blendingSpace;
  newDoc.viewPreferences.horizontalMeasurementUnits = app.activeDocument.viewPreferences.horizontalMeasurementUnits;
  newDoc.viewPreferences.verticalMeasurementUnits = app.activeDocument.viewPreferences.verticalMeasurementUnits;

  try {
    // Match page size to source page.
    // Use raw bounds in the doc's native unit — measurement units are already
    // copied above, so InDesign interprets these values in the correct unit.
    // (Converting to points and then passing them would cause "out of range"
    // errors when the document unit is inches or mm.)
    const b = pg.bounds;
    const wRaw = Math.abs(Number(b[3]) - Number(b[1]));
    const hRaw = Math.abs(Number(b[2]) - Number(b[0]));
    supportLog.info("indd_temp_document_size", { wRaw, hRaw });
    newDoc.documentPreferences.pageWidth = wRaw;
    newDoc.documentPreferences.pageHeight = hRaw;

    // Duplicate the source page into the new document
    pg.duplicate(LocationOptions.AFTER, newDoc.pages.item(0));

    // Remove the blank first page that was created with the new doc
    if (newDoc.pages.length > 1) {
      newDoc.pages.item(0).remove();
    }

    // Save as .indd
    const savePath = `${outPath}/${baseName}.indd`;
    await newDoc.save(savePath);

    return { ok: true };
  } catch (e) {
    return { ok: false, error: e.message };
  } finally {
    try { newDoc.close(SaveOptions.NO); } catch (e) { }
  }
}

async function exportPageToTmpFile(doc, pageNumber, tmpPath, isPng, exportDpi, pngTransparent) {
  const absPageString = `+${pageNumber}`;

  supportLog.info("image_temp_export_from_original_doc", {
    pageNumber,
    isPng,
    exportDpi,
    tmpPath
  });

  if (isPng) {
    const pp = app.pngExportPreferences;
    pp.exportResolution = exportDpi;
    pp.transparentBackground = pngTransparent;
    pp.antiAlias = true;
    pp.pngExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
    pp.pageString = absPageString;

    doc.exportFile(ExportFormat.PNG_FORMAT, tmpPath, false);
  } else {
    const jp = app.jpegExportPreferences;
    jp.exportResolution = exportDpi;
    jp.jpegQuality = JPEGOptionsQuality.MAXIMUM;
    jp.antiAlias = true;
    jp.jpegExportRange = ExportRangeOrAllPages.EXPORT_RANGE;
    jp.pageString = absPageString;

    doc.exportFile(ExportFormat.JPG, tmpPath, false);
  }
}

async function deleteProcessingTempFolder(folder, rootFolder, location) {
  if (!folder) return;

  const folderPath = folder.nativePath || "";

  try {
    const entries = await folder.getEntries();

    supportLog.info("processing_temp_cleanup_started", {
      location: location || "",
      path: folderPath,
      count: entries.length,
      entries: entries.map(e => e.name || e.nativePath || "")
    });

    for (const entry of entries) {
      try {
        await entry.delete();

        supportLog.info("processing_temp_entry_deleted", {
          location: location || "",
          entry: entry.name || entry.nativePath || ""
        });
      } catch (entryErr) {
        supportLog.warn("processing_temp_entry_delete_failed", {
          location: location || "",
          entry: entry.name || entry.nativePath || "",
          message: entryErr.message
        });
      }
    }

    await delay(150);

    const remaining = await folder.getEntries();

    supportLog.info("processing_temp_cleanup_finished", {
      location: location || "",
      path: folderPath,
      remainingCount: remaining.length,
      remainingEntries: remaining.map(e => e.name || e.nativePath || "")
    });

    if (!remaining.length) {
      try {
        await delay(150);
        await folder.delete();

        supportLog.info("processing_temp_session_folder_deleted", {
          location: location || "",
          path: folderPath
        });
      } catch (deleteErr) {
        supportLog.warn("processing_temp_session_folder_delete_failed", {
          location: location || "",
          path: folderPath,
          message: deleteErr.message
        });
      }

      if (rootFolder) {
        let rootPath = "";
        try { rootPath = rootFolder.nativePath || ""; } catch (_) {}
        try {
          const rootEntries = await rootFolder.getEntries();
          if (!rootEntries.length) {
            await rootFolder.delete();
            supportLog.info("processing_temp_root_folder_deleted", {
              location: location || "",
              path: rootPath
            });
          }
        } catch (rootErr) {
          supportLog.warn("processing_temp_root_folder_delete_failed", {
            location: location || "",
            path: rootPath,
            message: rootErr.message
          });
        }
      }
    }

  } catch (err) {
    supportLog.warn("processing_temp_cleanup_failed", {
      location: location || "",
      path: folderPath,
      message: err.message,
      stack: err.stack || ""
    });
  }
}

module.exports = { init, setStatusDetail };
